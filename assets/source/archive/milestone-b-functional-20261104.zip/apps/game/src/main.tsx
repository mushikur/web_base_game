import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import "@fontsource/noto-sans-bengali/400.css";
import "@fontsource/noto-sans-bengali/600.css";
import "@fontsource/noto-sans-bengali/700.css";
import "@fontsource/noto-sans-bengali/800.css";
import { bn, content, tutorialSteps, type Item } from "@neta/shared";
import type { DhakaGame, Snapshot } from "./game";
import "./style.css";
import { AudioSettings } from "./AudioSettings";

function Icon({ name, size = 22 }: { name: string; size?: number }) {
  const paths: Record<string, React.ReactNode> = {
    arrow: (
      <>
        <path d="M4 12h15M13 6l6 6-6 6" />
      </>
    ),
    pause: (
      <>
        <path d="M8 5v14M16 5v14" />
      </>
    ),
    sun: (
      <>
        <circle cx="12" cy="12" r="4" />
        <path d="M12 1v3m0 16v3M1 12h3m16 0h3M4 4l2 2m12 12 2 2M4 20l2-2M18 6l2-2" />
      </>
    ),
    sound: (
      <>
        <path d="M4 9v6h4l5 4V5L8 9H4Zm13-1q6 4 0 8m2-11q9 7 0 14" />
      </>
    ),
    settings: (
      <>
        <path d="m9 3-1 3-3 1-2 4 2 2v4l4 2 3-1 3 1 4-2v-4l2-2-2-4-3-1-1-3Z" />
        <circle cx="12" cy="11" r="3" />
      </>
    ),
    close: <path d="m6 6 12 12M6 18 18 6" />,
    pin: (
      <>
        <path d="M18 9c0 5-6 11-6 11S6 14 6 9a6 6 0 1 1 12 0Z" />
        <circle cx="12" cy="9" r="2" />
      </>
    ),
    egg: <path d="M19 14c0 5-14 5-14 0C5 8 9 3 12 3s7 5 7 11Z" />,
    sandal: (
      <>
        <path d="M8 3c3-2 8 0 8 4l2 12c-1 3-9 4-11 0L6 8c0-3 1-4 2-5Z" />
        <path d="m7 10 5-3 5 3m-5-3v5" />
      </>
    ),
    heart: (
      <path d="M20 5c-3-3-7 0-8 2-1-2-5-5-8-2-5 5 8 15 8 15S25 10 20 5Z" />
    ),
    target: (
      <>
        <circle cx="12" cy="12" r="8" />
        <circle cx="12" cy="12" r="3" />
        <path d="M12 1v4m0 14v4M1 12h4m14 0h4" />
      </>
    ),
    rickshaw: (
      <>
        <circle cx="5" cy="17" r="3" />
        <circle cx="20" cy="17" r="3" />
        <path d="m5 17 4-8 5 8H5m9 0 4-10h3M8 5h4M2 12V5c1-5 12-5 13 0v7m-13 0h11M4 6h8" />
      </>
    ),
    hand: (
      <>
        <path d="M7 13V7a1.5 1.5 0 0 1 3 0v4-7a1.5 1.5 0 0 1 3 0v7-5a1.5 1.5 0 0 1 3 0v6-3a1.5 1.5 0 0 1 3 0v7c0 7-10 8-13 3l-4-6c-1-2 2-3 3-1l2 2Z" />
      </>
    ),
    move: (
      <>
        <path d="M12 3v18M3 12h18m-5-5 5 5-5 5M7 7l-5 5 5 5M7 7l5-5 5 5M7 17l5 5 5-5" />
      </>
    ),
    camera: (
      <>
        <path d="m3 8 5-1 2-3h4l2 3 5 1v12H3Z" />
        <circle cx="12" cy="13" r="4" />
      </>
    ),
    run: (
      <>
        <circle cx="15" cy="4" r="2" />
        <path d="m7 9 5-2 5 5 4-1M12 7l-2 7 6 3v5M10 14l-6 7M2 6h5M1 10h4" />
      </>
    ),
    map: (
      <>
        <path d="m2 6 6-3 8 3 6-3v16l-6 3-8-3-6 3Zm6-3v16m8-13v16" />
      </>
    ),
    pickup: (
      <>
        <path d="M4 16v5h16v-5M12 3v13m-5-5 5 5 5-5" />
      </>
    ),
    select: (
      <>
        <rect x="2" y="5" width="8" height="14" rx="2" />
        <rect x="14" y="5" width="8" height="14" rx="2" />
        <path d="m16 13 2 2 3-5" />
      </>
    ),
    use: (
      <>
        <path d="m3 19 8-8m-5-1 5 1 1 5m1-10 2-3m2 6 4-1m-5 5 3 3" />
        <circle cx="8" cy="16" r="5" />
      </>
    ),
    vehicle: (
      <>
        <path d="M4 17V7l3-4h10l3 4v10ZM4 8h16M8 3v5m8-5v5M3 13h4m10 0h4M6 17v4m12-4v4" />
      </>
    ),
    board: (
      <>
        <path d="M14 3h7v18h-7M2 12h14m-5-5 5 5-5 5" />
      </>
    ),
    mission: (
      <>
        <path d="M6 22V3m0 1c5-5 7 5 14 0v9c-7 5-9-5-14 0" />
      </>
    ),
  };
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name] ?? paths.target}
    </svg>
  );
}

function MiniMap({
  s,
  expanded = false,
  onOpen,
}: {
  s: Snapshot;
  expanded?: boolean;
  onOpen?: () => void;
}) {
  const px = 75 + s.x * 5,
    pz = 142 - (s.z + 9) * 3.2;
  return (
    <aside
      className={`minimap ${expanded ? "map-expanded" : ""}`}
      aria-label="প্রতিশ্রুতি মোড়ের ছোট মানচিত্র"
    >
      <div className="map-head">
        <Icon name="pin" size={15} />
        <span>প্রতিশ্রুতি মোড়</span>
        <span className="north">উ</span>
      </div>
      <svg
        viewBox="0 0 150 170"
        className="map-svg"
        role="img"
        aria-label="আপনি, চায়ের দোকান, ডিম, স্যান্ডেল এবং সভার অবস্থান"
      >
        <defs>
          <pattern
            id="map-grid"
            width="16"
            height="16"
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M16 0H0V16"
              fill="none"
              stroke="#e6d5ac"
              strokeWidth=".4"
            />
          </pattern>
        </defs>
        <rect width="150" height="170" fill="#d8d3b5" />
        <rect width="150" height="170" fill="url(#map-grid)" />
        <path d="M53 0h44v170H53Z" fill="#6b796a" />
        <path
          d="M74 0v170"
          stroke="#d7caa4"
          strokeWidth="1"
          strokeDasharray="4 6"
        />
        {[10, 48, 92, 132].map((z, i) => (
          <g key={z}>
            <rect
              x="9"
              y={z}
              width="35"
              height="28"
              rx="2"
              fill={i === 2 ? "#b77847" : "#b4b298"}
            />
            <rect x="107" y={z} width="35" height="28" rx="2" fill="#b4b298" />
          </g>
        ))}
        <text x="26" y="111" textAnchor="middle" fontSize="9" fill="#fef1d2">
          চা
        </text>
        <circle cx="83" cy="78" r="4" fill="#8c3f30" />
        <circle cx="67" cy="131" r="3" fill="#edc65a" />
        <circle cx="81" cy="124" r="3" fill="#edc65a" />
        <g transform="translate(75 98.3)" aria-label="প্রথম অভিযানের চিহ্ন">
          <circle r="7" fill="#efc765" stroke="#563d24" strokeWidth="1.5" />
          <path
            d="M-2 4v-8l5 2-5 2"
            fill="none"
            stroke="#513421"
            strokeWidth="1.3"
          />
        </g>
        <g transform="translate(95 106.8)" aria-label="সবুজ সিএনজি">
          <rect
            x="-5"
            y="-4"
            width="10"
            height="8"
            rx="2"
            fill="#1a7c55"
            stroke="#f7e6bb"
            strokeWidth="1"
          />
        </g>
        <g
          transform={`translate(${Math.max(5, Math.min(145, px))} ${Math.max(5, Math.min(160, pz))}) rotate(${(s.yaw * 180) / Math.PI})`}
        >
          <path
            d="m0-7 5 12-5-2-5 2Z"
            fill="#fff7d8"
            stroke="#183e34"
            strokeWidth="1.8"
          />
        </g>
      </svg>
      <div className="map-legend">
        <i /> আপনি <i className="target-dot" /> সভা
      </div>
      {!expanded && (
        <button
          className="map-open-button"
          aria-label="বড় মানচিত্র খুলুন"
          onClick={onOpen}
        >
          <Icon name="map" size={14} />
          <span>মানচিত্র</span>
          <kbd>M</kbd>
        </button>
      )}
    </aside>
  );
}

function TutorialPanel({ s, game }: { s: Snapshot; game: DhakaGame }) {
  const step = tutorialSteps[s.tutorial.stepIndex];
  if (!s.tutorialOpen || !step) return null;
  return (
    <section
      className="tutorial-panel"
      aria-label="খেলা শেখার নির্দেশনা"
      data-testid="tutorial-panel"
    >
      <div className="tutorial-top">
        <span className="tutorial-icon">
          <Icon name={step.icon} size={27} />
        </span>
        <div>
          <span className="tutorial-kicker">গলি চেনার পাঠ</span>
          <strong>
            ধাপ {bn(s.tutorial.stepIndex + 1)} / {bn(tutorialSteps.length)}
          </strong>
        </div>
        <span className="tutorial-safety">নিরাপদ অনুশীলন</span>
      </div>
      <div className="tutorial-progress" aria-hidden="true">
        {tutorialSteps.map((entry, i) => (
          <i
            key={entry.id}
            className={i <= s.tutorial.stepIndex ? "done" : ""}
          />
        ))}
      </div>
      <h2 aria-live="polite">{step.title}</h2>
      <p>{step[s.inputMode]}</p>
      <div className="tutorial-guide">
        <Icon name="pin" size={15} />
        <span>{s.tutorialGuide}</span>
      </div>
      <footer>
        <label>
          <input
            type="checkbox"
            checked={s.dontShowTutorial}
            onChange={(event) => game.setDontShowTutorial(event.target.checked)}
          />
          আর দেখাবেন না
        </label>
        <button onClick={() => game.skipTutorial()}>
          এড়িয়ে যান <Icon name="arrow" size={15} />
        </button>
      </footer>
    </section>
  );
}

function ExpandedMap({ s, game }: { s: Snapshot; game: DhakaGame }) {
  return (
    <div className="map-backdrop">
      <section
        className="expanded-map-panel"
        role="dialog"
        aria-modal="true"
        aria-labelledby="map-title"
      >
        <header>
          <div>
            <span className="eyebrow">পাড়ার পথঘাট</span>
            <h2 id="map-title">প্রতিশ্রুতি মোড়</h2>
          </div>
          <button
            autoFocus
            className="icon-button"
            aria-label="মানচিত্র বন্ধ করুন"
            onClick={() => game.map(false)}
          >
            <Icon name="close" />
          </button>
        </header>
        <div className="expanded-map-body">
          <MiniMap s={s} expanded />
          <div className="map-destinations">
            <p>চিহ্ন বেছে অবস্থান ও কাজ দেখুন।</p>
            <button
              className={s.selectedMapMarker === "mission" ? "active" : ""}
              onClick={() => game.viewFirstMarker()}
              aria-pressed={s.selectedMapMarker === "mission"}
            >
              <Icon name="mission" />
              <span>
                <strong>প্রথম অভিযানের চিহ্ন</strong>
                <small>সভার সামনে সোনালি বৃত্ত</small>
              </span>
            </button>
            <button
              className={s.selectedMapMarker === "vehicle" ? "active" : ""}
              onClick={() => game.viewVehicleMarker()}
              aria-pressed={s.selectedMapMarker === "vehicle"}
            >
              <Icon name="vehicle" />
              <span>
                <strong>সবুজ সিএনজি</strong>
                <small>সভার আগে ডান পাশে • খালি সিট ১টি</small>
              </span>
            </button>
            {s.selectedMapMarker === "mission" && (
              <article className="marker-detail" aria-live="polite">
                <span>এই গলির লক্ষ্য</span>
                <h3>সভা শেষ, রাস্তা খোলা!</h3>
                <p>{content.mission}</p>
                <small>সামনের সোনালি বৃত্তটি অভিযানের অবস্থান দেখায়।</small>
              </article>
            )}
            {s.selectedMapMarker === "vehicle" && (
              <article className="marker-detail" aria-live="polite">
                <span>সিটে ওঠার অনুশীলন</span>
                <h3>সবুজ সিএনজি</h3>
                <p>
                  খোলা পাশের দরজার কাছে গিয়ে মিথস্ক্রিয়া করুন। বসে চারপাশ দেখুন,
                  তারপর নিরাপদে নামুন।
                </p>
              </article>
            )}
            <div className="map-key">
              <span>● ডিম ও স্যান্ডেল</span>
              <span>▣ সিএনজি</span>
              <span>⚑ অভিযানের চিহ্ন</span>
            </div>
            <button className="secondary" onClick={() => game.map(false)}>
              গলিতে ফিরুন <Icon name="arrow" size={18} />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}

function Joystick({ game }: { game: DhakaGame }) {
  const ref = useRef<HTMLDivElement>(null);
  const [point, setPoint] = useState({ x: 0, y: 0 });
  const update = (e: React.PointerEvent) => {
    const r = ref.current!.getBoundingClientRect(),
      x = (e.clientX - r.left - r.width / 2) / 38,
      y = (e.clientY - r.top - r.height / 2) / 38,
      l = Math.max(1, Math.hypot(x, y));
    setPoint({ x: (x / l) * 30, y: (y / l) * 30 });
    game.joystick(x / l, y / l);
  };
  const end = () => {
    setPoint({ x: 0, y: 0 });
    game.joystick(0, 0);
  };
  return (
    <div
      ref={ref}
      className="joystick"
      role="group"
      aria-label="চলার স্পর্শ নিয়ন্ত্রণ"
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        update(e);
      }}
      onPointerMove={(e) => {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) update(e);
      }}
      onPointerUp={end}
      onPointerCancel={end}
    >
      <div style={{ transform: `translate(${point.x}px,${point.y}px)` }} />
      <span>চলুন</span>
    </div>
  );
}

function App() {
  const canvas = useRef<HTMLCanvasElement>(null),
    game = useRef<DhakaGame | null>(null);
  const [s, setS] = useState<Snapshot | null>(null),
    [settings, setSettings] = useState(false),
    [help, setHelp] = useState(false),
    [startupError, setStartupError] = useState("");
  useEffect(() => {
    let g: DhakaGame | undefined;
    let cancelled = false;
    void import("./game")
      .then(({ DhakaGame }) => {
        if (cancelled) return;
        g = new DhakaGame(canvas.current!, setS);
        game.current = g;
        void g.init();
      })
      .catch((error: unknown) => {
        console.error(error);
        if (!cancelled)
          setStartupError(
            "এই ব্রাউজারে ত্রিমাত্রিক দৃশ্য চালু করা যায়নি। হালনাগাদ ব্রাউজারে আবার চেষ্টা করুন।",
          );
      });
    return () => {
      cancelled = true;
      g?.dispose();
    };
  }, []);
  const g = game.current;
  const openSettings = () => {
    setSettings(true);
    if (s?.playing && !s.paused) g?.pause();
  };
  const closeSettings = () => {
    setSettings(false);
    if (s?.playing && s.paused) g?.pause();
  };
  useEffect(() => {
    if (!settings && !help && !s?.paused && !s?.mapOpen && !s?.spawnBlocked)
      return;
    const prior = document.activeElement as HTMLElement | null;
    const handle = (event: KeyboardEvent) => {
      if (
        event.key === "Escape" &&
        (settings || help || game.current?.state.mapOpen)
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
        if (settings) {
          setSettings(false);
          if (game.current?.state.playing && game.current.state.paused)
            game.current.pause();
        }
        setHelp(false);
        if (game.current?.state.mapOpen) game.current.map(false);
      }
      if (event.key === "Tab") {
        const dialog = document.querySelector<HTMLElement>('[role="dialog"]');
        const controls = Array.from(
          dialog?.querySelectorAll<HTMLElement>(
            'button,a[href],input,select,[tabindex="0"]',
          ) ?? [],
        ).filter((e) => e.offsetParent !== null);
        if (!controls.length) return;
        const first = controls[0],
          last = controls[controls.length - 1];
        if (
          event.shiftKey &&
          (document.activeElement === first ||
            !dialog?.contains(document.activeElement))
        ) {
          event.preventDefault();
          last.focus();
        } else if (
          !event.shiftKey &&
          (document.activeElement === last ||
            !dialog?.contains(document.activeElement))
        ) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener("keydown", handle, true);
    return () => {
      window.removeEventListener("keydown", handle, true);
      if (
        game.current?.state.playing &&
        !game.current.state.paused &&
        !game.current.state.mapOpen &&
        !game.current.state.spawnBlocked
      )
        canvas.current?.focus();
      else if (prior?.isConnected) prior.focus();
    };
  }, [settings, help, s?.paused, s?.mapOpen, s?.spawnBlocked]);
  return (
    <main
      className={`app ${s?.playing ? "is-playing" : ""} input-${s?.inputMode ?? "desktop"} ${s?.tutorialOpen ? "is-tutorial" : ""}`}
    >
      <canvas
        ref={canvas}
        className="game-canvas"
        tabIndex={0}
        aria-label="ঢাকার কাল্পনিক গলির ত্রিমাত্রিক খেলা"
      />
      <div className="scene-vignette" />
      {!s?.ready && (
        <div className="loading">
          <div className="loading-mark">
            <Icon name="rickshaw" size={52} />
          </div>
          <p>ঢাকার গলিতে স্বাগতম</p>
          <h1>{content.title}</h1>
          <span>
            {startupError ||
              s?.error ||
              "গলি সাজানো হচ্ছে… চায়ের কেটলিটা বসুক!"}
          </span>
          {s?.error || startupError ? (
            <button className="primary" onClick={() => location.reload()}>
              আবার চেষ্টা করুন
            </button>
          ) : (
            <div className="loading-line">
              <i />
            </div>
          )}
          <small>সব চরিত্র ও ঘটনা কাল্পনিক</small>
        </div>
      )}
      {s?.ready && !s.playing && (
        <>
          <header className="home-header">
            <a className="brand" href="#" aria-label="নেতা উঠছে! প্রচ্ছদ">
              <span className="brand-icon">
                <Icon name="rickshaw" size={28} />
              </span>
              <strong>
                নেতা উঠছে<span>!</span>
              </strong>
            </a>
            <nav>
              <span className="edition">
                <i /> ঢাকার গল্প, আপনার খেলা
              </span>
              <button
                className="icon-button"
                aria-label="সেটিংস খুলুন"
                onClick={openSettings}
              >
                <Icon name="settings" />
              </button>
            </nav>
          </header>
          <section className="home-copy">
            <div className="eyebrow">
              <span /> স্বাগতম, প্রতিশ্রুতি মোড়ে
            </div>
            <h1>
              নেতা
              <br />
              <span>উঠছে!</span>
              <svg viewBox="0 0 300 25" aria-hidden="true">
                <path
                  d="M8 15Q130-3 285 10M40 24Q190 6 272 20"
                  stroke="currentColor"
                  strokeWidth="5"
                  fill="none"
                />
              </svg>
            </h1>
            <h2>{content.slogan}</h2>
            <p>
              চায়ের কাপে ঝড়, রাস্তায় সভা।
              <br />
              এই গলির জট খুলবেন আপনিই!
            </p>
            <button className="primary play-button" onClick={() => g?.start()}>
              <span>গলিতে নামুন</span>
              <Icon name="arrow" size={25} />
            </button>
            <button className="text-button" onClick={() => setHelp(true)}>
              <span className="help-circle">?</span> কীভাবে খেলবেন
            </button>
            <div className="home-meta">
              <span>
                <Icon name="pin" size={15} /> এক টুকরো কাল্পনিক ঢাকা
              </span>
              <span>একক খেলা</span>
            </div>
          </section>
          <aside className="street-caption">
            <span className="caption-line" />
            <div>
              <small>আজকের ঠিকানা</small>
              <h3>কেটলি কেবিনেট</h3>
              <p>গরম চা, ঠান্ডা প্রতিশ্রুতি।</p>
            </div>
            <span className="area-number">০১</span>
          </aside>
          <footer className="home-footer">
            <span>হাসির খেলা। সব চরিত্র ও সংগঠন কাল্পনিক।</span>
            <span>
              তৈরি বাংলায়, ঢাকার মেজাজে <i>✦</i>
            </span>
          </footer>
        </>
      )}
      {s?.playing && g && (
        <>
          <header className="hud-header">
            <div className="player-card">
              <div className="avatar-monogram">স</div>
              <div>
                <strong>সজল পথিক</strong>
                <div className="health-line">
                  <Icon name="heart" size={13} />
                  <div className="health-track">
                    <i style={{ width: `${s.health}%` }} />
                  </div>
                  <span>{bn(s.health)}</span>
                </div>
              </div>
              <div className="score">
                <span>পয়েন্ট</span>
                <b>{bn(s.score).padStart(2, "০")}</b>
              </div>
            </div>
            <div className="location-pill">
              <i />
              {content.location}
              <span>{s.evening ? "বিকেলের আলো" : "দিনের আলো"}</span>
            </div>
            <div className="hud-tools">
              <button
                className="icon-button"
                aria-label={s.muted ? "শব্দ চালু করুন" : "শব্দ বন্ধ করুন"}
                onClick={() => g.mute()}
              >
                <Icon name="sound" />
                {s.muted && <i className="muted-slash" />}
              </button>
              <button
                className="icon-button"
                aria-label="বিরতি"
                onClick={() => g.pause()}
              >
                <Icon name="pause" />
              </button>
              <button
                className="icon-button"
                aria-label="সেটিংস খুলুন"
                onClick={openSettings}
              >
                <Icon name="settings" />
              </button>
            </div>
          </header>
          {!s.tutorialOpen && (
            <section className="mission">
              <div className="mission-label">
                <span>এই গলির কাজ</span>
                <Icon name="target" size={17} />
              </div>
              <h2>সভা শেষ, রাস্তা খোলা!</h2>
              <p>{content.mission}</p>
              <div>
                <span className="step-number">১</span>
                <span>
                  {s.egg + s.sandal > 0
                    ? "সামনে এগিয়ে সভার দিকে লক্ষ্য করুন"
                    : "কাছের ডিম ও স্যান্ডেল কুড়িয়ে নিন"}
                </span>
              </div>
            </section>
          )}
          <TutorialPanel s={s} game={g} />
          <div className="crosshair" aria-hidden="true">
            <i />
            <i />
            <i />
            <i />
          </div>
          {s.target && (
            <aside className="target-status">
              <span>{s.target}</span>
              <div>
                <i style={{ width: `${s.targetHealth}%` }} />
              </div>
              <small>
                {s.targetHealth <= 0
                  ? "আজকের মতো ক্ষান্ত!"
                  : `ধৈর্য ${bn(s.targetHealth)}`}
              </small>
            </aside>
          )}
          <MiniMap s={s} onOpen={() => g.map(true)} />
          {s.vehiclePrompt && (
            <div className="vehicle-context" role="status">
              <Icon name="vehicle" size={19} />
              {s.vehiclePrompt}
            </div>
          )}
          <div className="game-notice" role="status">
            {s.message}
          </div>
          {s.subtitle && (
            <div className="subtitle" aria-live="polite">
              {s.subtitle}
            </div>
          )}
          <div className="inventory" aria-label="সঙ্গে থাকা জিনিস">
            {(["egg", "sandal"] as Item[]).map((kind, i) => (
              <button
                key={kind}
                className={`item-slot ${s.selected === kind ? "selected" : ""}`}
                onClick={() => g.select(kind)}
                aria-label={`${content.items[kind]} বাছুন, ${bn(s[kind])}টি`}
                aria-pressed={s.selected === kind}
                disabled={s.boardingState !== "onFoot"}
              >
                <span className="key-hint">{i + 1}</span>
                <Icon name={kind} size={30} />
                <span className="item-name">{content.items[kind]}</span>
                <b>× {bn(s[kind])}</b>
              </button>
            ))}
          </div>
          <div className="desktop-controls">
            <span>
              <kbd>W A S D</kbd> চলুন
            </span>
            <span>
              <kbd>Shift</kbd> দৌড়
            </span>
            <span>
              <kbd>E</kbd> মিথস্ক্রিয়া
            </span>
            <span>
              <kbd>Enter</kbd> ব্যবহার
            </span>
            <span>
              <kbd>Tab</kbd> গাড়ি • <kbd>M</kbd> মানচিত্র
            </span>
            <span>টেনে ক্যামেরা • চাকা দিয়ে জিনিস বদলান</span>
          </div>
          <div className="action-buttons">
            <button
              className={`pickup-button ${s.nearPickup || s.nearVehicle ? "near" : ""}`}
              onClick={() => g.context()}
              aria-label={
                s.boardingState === "seated"
                  ? "সিএনজি থেকে নামুন"
                  : s.nearVehicle
                    ? "সিএনজিতে উঠুন"
                    : "কাছের জিনিস কুড়ান"
              }
            >
              <Icon
                name={
                  s.nearVehicle || s.boardingState !== "onFoot"
                    ? "vehicle"
                    : "hand"
                }
              />
              <span>
                {s.boardingState === "seated"
                  ? "নামুন"
                  : s.nearVehicle
                    ? "গাড়ি"
                    : "কুড়ান"}
              </span>
            </button>
            <button
              className="throw-button"
              onClick={() => g.throw()}
              disabled={s.boardingState !== "onFoot"}
            >
              <Icon name="target" size={29} />
              <span>ব্যবহার</span>
            </button>
          </div>
          <div
            className="camera-tools"
            role="group"
            aria-label="ক্যামেরার দূরত্ব"
          >
            <button
              aria-label="ক্যামেরা কাছে আনুন"
              onClick={() => g.zoom(-0.6)}
            >
              <span aria-hidden="true">＋</span> কাছে
            </button>
            <button aria-label="ক্যামেরা দূরে নিন" onClick={() => g.zoom(0.6)}>
              <span aria-hidden="true">−</span> দূরে
            </button>
          </div>
          <div className="mobile-controls">
            <Joystick game={g} />
            <button
              className="run-button"
              aria-label={s.runEnabled ? "দৌড় বন্ধ করুন" : "দৌড় চালু করুন"}
              aria-pressed={s.runEnabled}
              onClick={() => g.run()}
            >
              দৌড়
            </button>
          </div>
          {s.mapOpen && <ExpandedMap s={s} game={g} />}
          {s.spawnBlocked && (
            <div className="modal-backdrop">
              <section
                className="dialog"
                role="dialog"
                aria-modal="true"
                aria-labelledby="spawn-title"
              >
                <span className="eyebrow">একটু অপেক্ষা</span>
                <h2 id="spawn-title">নিরাপদ জায়গা খালি নেই।</h2>
                <p>
                  নির্ধারিত কোনো স্থান এখন খালি পাওয়া যায়নি। আবার চেষ্টা করুন।
                </p>
                <button autoFocus className="primary" onClick={() => g.start()}>
                  আবার চেষ্টা করুন <Icon name="arrow" />
                </button>
                <button className="text-button" onClick={() => g.home()}>
                  প্রচ্ছদে ফিরুন
                </button>
              </section>
            </div>
          )}
          {s.paused && !settings && (
            <div className="modal-backdrop">
              <section
                className="dialog pause-dialog"
                role="dialog"
                aria-modal="true"
                aria-labelledby="pause-title"
              >
                <span className="eyebrow">এক কাপ চায়ের বিরতি</span>
                <h2 id="pause-title">গলি অপেক্ষায় আছে।</h2>
                <p>
                  পয়েন্ট {bn(s.score)} • ছুড়েছেন {bn(s.throws)} বার
                </p>
                <button autoFocus className="primary" onClick={() => g.pause()}>
                  {s.health === 0 ? "আবার শুরু করুন" : "খেলায় ফিরুন"}{" "}
                  <Icon name="arrow" />
                </button>
                <button className="secondary" onClick={openSettings}>
                  সেটিংস
                </button>
                <button className="text-button" onClick={() => g.home()}>
                  প্রচ্ছদে ফিরুন
                </button>
              </section>
            </div>
          )}
        </>
      )}
      {settings && s && g && (
        <div className="modal-backdrop">
          <section
            className="dialog settings-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="settings-title"
          >
            <button
              className="dialog-close icon-button"
              aria-label="সেটিংস বন্ধ করুন"
              onClick={closeSettings}
            >
              <Icon name="close" />
            </button>
            <span className="eyebrow">আপনার মতো করে</span>
            <h2 id="settings-title">খেলার সেটিংস</h2>
            <fieldset>
              <legend>দৃশ্যের মান</legend>
              <div className="segmented">
                <button
                  className={s.quality === "desktop" ? "active" : ""}
                  aria-pressed={s.quality === "desktop"}
                  onClick={() => g.setQuality("desktop")}
                >
                  কম্পিউটার<span>বিস্তারিত ছায়া ও আলো</span>
                </button>
                <button
                  className={s.quality === "mobile" ? "active" : ""}
                  aria-pressed={s.quality === "mobile"}
                  onClick={() => g.setQuality("mobile")}
                >
                  মোবাইল<span>হালকা দৃশ্য, সহজে চলুক</span>
                </button>
              </div>
            </fieldset>
            <fieldset>
              <legend>গলির সময়</legend>
              <div className="segmented">
                <button
                  className={!s.evening ? "active" : ""}
                  aria-pressed={!s.evening}
                  onClick={() => g.setEvening(false)}
                >
                  দিনের আলো
                </button>
                <button
                  className={s.evening ? "active" : ""}
                  aria-pressed={s.evening}
                  onClick={() => g.setEvening(true)}
                >
                  বিকেলের আলো
                </button>
              </div>
            </fieldset>
            <AudioSettings audio={g.audio} />
            <fieldset className="tutorial-settings">
              <legend>গলি চেনার পাঠ</legend>
              <p>
                শেখা আবার শুরু করলে আপনার জায়গা, পয়েন্ট ও সঙ্গে থাকা জিনিস রাখা
                হবে। গাড়িতে থাকলে আগে নিরাপদে নামুন।
              </p>
              {s.playing && s.health <= 0 && (
                <p role="status">
                  আগে নতুন করে খেলুন, তারপর শেখা আবার চালু করুন।
                </p>
              )}
              <button
                className="secondary"
                disabled={
                  s.playing && (s.health <= 0 || s.boardingState !== "onFoot")
                }
                onClick={() => {
                  if (!s.playing) g.start();
                  if (g.replayTutorial()) closeSettings();
                }}
              >
                শেখা আবার শুরু করুন <Icon name="arrow" size={18} />
              </button>
              <label>
                <input
                  type="checkbox"
                  checked={s.dontShowTutorial}
                  onChange={(event) =>
                    g.setDontShowTutorial(event.target.checked)
                  }
                />
                আর দেখাবেন না
              </label>
            </fieldset>
            <p className="language-note">
              ভাষা: বাংলা
              <br />
              <span>বাংলা লেখা, সংলাপ ও নির্দেশনাসহ।</span>
            </p>
            <button className="primary" autoFocus onClick={closeSettings}>
              ঠিক আছে <Icon name="arrow" />
            </button>
          </section>
        </div>
      )}
      {help && (
        <div className="modal-backdrop">
          <section
            className="dialog help-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="help-title"
          >
            <button
              className="dialog-close icon-button"
              aria-label="নির্দেশনা বন্ধ করুন"
              onClick={() => setHelp(false)}
            >
              <Icon name="close" />
            </button>
            <span className="eyebrow">গলির নিয়মকানুন</span>
            <h2 id="help-title">চলুন, রাস্তা খুলি।</h2>
            <ol>
              <li>ডিম আর স্যান্ডেলের কাছে গিয়ে কুড়িয়ে নিন।</li>
              <li>সভায় থাকা কাল্পনিক নেতাকর্মীদের দিকে লক্ষ্য করুন।</li>
              <li>ছুড়ুন, পয়েন্ট পান। পথচারীকে লাগলে পয়েন্ট নেই।</li>
            </ol>
            <p>
              কম্পিউটারে <kbd>W A S D</kbd> বা তীরচিহ্নে চলুন, <kbd>Shift</kbd>{" "}
              ধরে দৌড়ান। <kbd>E</kbd> দিয়ে মিথস্ক্রিয়া, ক্লিক বা{" "}
              <kbd>Enter</kbd> দিয়ে ব্যবহার করুন। দৃশ্য টেনে ক্যামেরা ঘোরান। 1 /
              2 বা মাউসের চাকা দিয়ে জিনিস বদলান। <kbd>Tab</kbd> দিয়ে গাড়িতে উঠুন
              বা নামুন, <kbd>M</kbd> দিয়ে মানচিত্র খুলুন। <kbd>Space</kbd> দিয়েও
              ছুড়তে পারেন।
            </p>
            <p>
              মোবাইলে বাঁয়ের গোল নিয়ন্ত্রণে চলুন, ডানের বোতামে কুড়ান ও ছুড়ুন।
              কাছে ও দূরে বোতাম দিয়ে ক্যামেরার দূরত্ব বদলান।
            </p>
            <button
              className="primary"
              autoFocus
              onClick={() => setHelp(false)}
            >
              বুঝেছি <Icon name="arrow" />
            </button>
          </section>
        </div>
      )}
      {new URLSearchParams(location.search).has("qa") && s?.ready && g && (
        <details className="qa-panel">
          <summary>পরীক্ষা • {bn(s.fps)} ফ্রেম/সে.</summary>
          <button onClick={() => g.resetBenchmark()}>নতুন মাপ নিন</button>
          <button
            disabled={
              s.boardingState !== "seated" && !g.diagnostics().qaExitBlocked
            }
            onClick={() => g.setQaExitBlocked(!g.diagnostics().qaExitBlocked)}
          >
            {g.diagnostics().qaExitBlocked
              ? "পরীক্ষার রেলিং সরান"
              : "নামার পথে পরীক্ষার রেলিং রাখুন"}
          </button>
          <output
            data-testid="runtime-evidence"
            data-evidence={JSON.stringify(g.diagnostics())}
          >
            <p>গড় {bn(g.diagnostics().fpsAverage)} ফ্রেম/সে.</p>
            <p>
              স্থান {s.x.toFixed(2)}, {s.z.toFixed(2)}
            </p>
            <p>
              কঙ্কাল {bn(g.diagnostics().skeletons)} • অ্যানিমেশন{" "}
              {bn(g.diagnostics().animationGroups)}
            </p>
            <p>{content.shapingSample}</p>
          </output>
        </details>
      )}
    </main>
  );
}
createRoot(document.getElementById("root")!).render(<App />);
