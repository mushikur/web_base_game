# Build plan

## Active expansion

Implement milestones A–H from `harness/context/004-expansion-request.md` in order, preserving the current game. Milestone A's audio/music Admin subset is a required dependency; do not mistake it for completion of all Admin modules. Use local standalone storage; preserve existing data and publication history. Record focused tests, broad regressions, actual browser flows and failures at every gate. A real blocker permits safe independent work but never an invented pass.

Current gate: A passed and B's functional scope is VERIFIED in `harness/milestone-b-acceptance.md`. Final CSdJS6tH adds only simulation-time diagnostics, passes60 tests/types/lint/both builds, and has actual focused desktop/mobile full patrol-cycle observations. User-authorized Chrome window focus resolved the earlier foreground blocker. Measured desktop29.7343FPS misses the global60FPS target; mobile viewport30.0006FPS is not Android qualification. C is READY against `harness/build/milestone-c.md`, with the accepted B source backup before dependent runtime edits. Carry the performance gap into profiling/optimization as C expands; do not call it a performance pass. Do not restart audio authoring or erase data/history.

## Historical slice plan

1. **Phase 00**: audit the intended directory and Git state; preserve any existing standalone game work; create or maintain the harness, language/content contract and gated phase specifications; consult current Context7 APIs and npm package metadata when reachable.
2. **Phase 01**: establish TypeScript/Vite/React/Babylon/Havok workspace; author original editable character/vehicle assets; build detailed street, controls, physical throws, Bengali UI and quality/audio presets.
3. **Evidence**: types/lint/domain tests/build; serve production locally; desktop and emulated mobile rendering and gameplay inspection; measured FPS and three camera screenshots. Record real limits honestly.
4. Stop at the Phase 01 gate. Failed visual or device criteria remain open, not silently approved.
