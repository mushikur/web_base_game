# Actual build evidence

## Phase 00 — 2026-11-02

Read-only audit completed before edits. Working directory empty; `git status` and `git rev-parse` both report not a Git repository. No unrelated application or user work found. Node 26.5.0 and npm 11.17.0 available; Blender not found on PATH. No database touched.

Harness created: AGENTS, GOALS, PLANS, seven gated phase specifications, context decisions, this log.

Current API references via Context7:
- Babylon official documentation: `await HavokPhysics()` then `new HavokPlugin(true, instance)` and `scene.enablePhysics`; Physics V2 aggregates; collision flags.
- Vite official documentation: Vite 8 supports Node >=22.12.0 (local Node satisfies).
- Colyseus official migration documentation: `colyseus`, `@colyseus/sdk`, `@colyseus/schema` current package families. Deferred without installation.

## Phase 01

Implementation and observed verification are appended below as work proceeds. No visual approval or device-performance claim is implied by this scaffold.

### Implemented

Standalone npm/TypeScript workspaces; Vite/React Bengali interface; Babylon 9.33.1; Havok 1.3.14 Physics V2. Reserved Admin/server folders contain boundary documentation only. Original reproducible skinned GLB (17 joints, five clips), ten runtime actors, detailed procedural architecture/props/vehicles and original local textures. Bundled Noto Sans Bengali and copied license notices. Spatial Web Audio uses synthesised motors/horns without voices. No database or external service is used.

Current npm metadata checked: Babylon 9.33.1, Havok 1.3.14, Vite 8.3.5, Colyseus 0.18.10, SDK 0.18.9, schema 5.0.43. Only packages needed for the slice installed. Context7's Colyseus migration examples used for package-family confirmation; multiplayer is deferred.

### Verification and fixes observed

- `npm run verify`: type checking, ESLint, 5 meaningful tests and production build passed after the last gameplay source change. Actual output saved in `harness/evidence/checks.txt`.
- Production preview served at http://127.0.0.1:4173/ and inspected using actual browser rendering.
- Desktop tested at 1280×720; mobile viewport at 390×844. Keyboard W moved forward; Shift+W covered about twice the distance. E collected eggs and sandals. Space/mobile throw button produced +8 for sandal and +5 for egg, with target health reductions and Bengali subtitles.
- Actual mobile joystick pointer hold changed z from -9 to about -7.33; touch collect and throw completed successfully (`mobile-joystick.json` and screenshots).
- Counter collision held x=-5.750775 before/after an additional 1-second A input (`collision.json`). That early file's draw-call field was cumulative, not a per-frame count; do not use it for performance comparisons. Per-frame counter was corrected later.
- Roof initially obscured the player. Added correct-height camera proxies for roof, awning and sign; close view observed with camera y≈2.46 instead of y≈3.91 (`camera-roof-fixed.*`). Camera now retracts immediately when obstructed. Corrected foot height at curbs/pavement.
- Side-facing Bengali signs initially showed their reverse side. Corrected plane orientation and visually read “কেটলি কেবিনেট” from the road. Bengali shaping sample checked on desktop/mobile. Danda U+0964 is shared Bengali punctuation, not evidence of Hindi text; no Devanagari letters were found. No Unicode replacement character was found. Mobile DOM scroll width matched viewport width (390).
- Pause retry passed with paused=true, suspended audio and identical before/after position (`pause-retry.json`). Preserve `pause.json` as an invalid initial test setup: it recorded paused=false, so its failed frozen result is not a pause-engine failure or a pass.
- Improved frame cost by stopping zero-weight animation groups, reducing distant tiny details and avoiding their shadow passes. Final captured 600-sample averages: desktop street 59.36, desktop evening 59.95, mobile viewport 59.98 FPS. These are local computer results, not Android hardware claims.
- Babylon warned while automatically inferring a sphere from the oval egg's bounds. Preserved the oval render geometry and assigned explicit, simple spherical collision radii (egg 0.1024 m, sandal 0.18 m); render and collider shape are deliberately separate. Last build and egg throw rechecked after this correction.
- Browser connection recovery was needed during verification; reconnecting the existing tab after a session reset worked. No app data was lost.
- Final explicit-collider egg smoke check produced +5 points, target health 75 and an empty new-run warning/error list (`final-egg-check.json`). Build/check output was refreshed after the final source change. Settings screenshots were inspected and recaptured after layout settled. Returned the browser to the ordinary, Bengali game URL and cleared the temporary viewport override.

### Art and gate

Three gameplay-angle screenshots plus home, settings, mobile and shaping proof are in `harness/evidence`. See `harness/phase-01-status.md` for the complete acceptance matrix and asset limitations. The functional slice is reviewable. The current character/vehicle artwork is stylized and is **not asserted to meet the final semi-realistic visual target**. No Phase 02–06 work has been started and no phase approval is inferred.

## Photo-led graphics revision — 2026-11-02

Scope stayed within Phase 01. Read-only audit preceded changes; prior files/model preserved in `assets/source/archive/phase01-before-photo-upgrade.zip`. Eleven supplied photographs were archived with dimensions, SHA-256 and reference roles. Real portraits/logos were not published. Geometry is authored, not photo reconstruction.

Rebuilt rickshaw/CNG/bus geometry in `vehicles.ts`; added asphalt/plaster/enamel/floral local material sets, HDR lighting/reflections, desktop SSAO, corrected puddle normals, foliage trees, drains, yellow pedestrian railings and original Bengali posters. Built-in imagegen produced the saved material atlas; exact prompt/mode are retained. Normal/ORM estimates were reduced to 512 square, bringing all twelve maps to about 3.1 MB. Added Sharp only as offline dev tooling. CC0 HDR from Poly Haven and its provenance are local.

Original skinned GLB now has six clips including Pickup, refined face/limbs/clothing and optional local garments. Ten actors share 17-joint anatomy, with garment/hair/skin/scale variants and ambient sidewalk Walk. Camera moved lower; orbit retained and wheel zoom implemented. Vehicle/median/tree colliders updated. Full detail and limitations: `harness/graphics-upgrade.md`.

### Actual fixes and verification

- New polygon vehicle panels initially failed static merging due to missing UV data. Added UVs and correct single-face normals/two-sided material; startup was retested successfully. Lower body lofts were adjusted to avoid enclosing seats. Sky blur causing an oversized sun glow was removed.
- Final gameplay-source `npm run verify` passed types, lint, six tests and production build. Output: `harness/evidence/graphics-v2-checks.txt`. Skin-weight normalization, six clips, PBR maps/HDR budgets and existing gameplay rules are checked. Vite retains a 2.67 MB 3D chunk advisory; no failed build.
- Production preview on port 4173 rendered in Chrome. IAB background throttled to roughly 1 FPS, so those results were excluded from performance claims. Saved 600-sample means: desktop street 60.00, desktop bus angle 53.31, mobile viewport 56.32 FPS. Other interactions showed 25–30 FPS. These are brief local-PC observations, not stable-frame-rate or real-phone qualification.
- At 390x844, mobile preset had HDR ready/AO off and no horizontal DOM overflow. Joystick moved from z=-9 to -7.61 and then to the egg pickup. Touch collect gave six eggs; throw consumed one, scored +5 and reduced target to 75 health. `graphics-v2/mobile-*.json`.
- Shift+W traversed to the bus. New divider blocked x at -0.8832547257 before/after additional D input while permitting sliding along z. Escape pause held the same position during W input and suspended audio. `graphics-v2/divider-collision.json`, `pause.json`.
- Bengali shaping sample was visually inspected on desktop/mobile; bn-BD, bundled Noto Sans Bengali, no replacement character or Devanagari letters. New test-tab warning/error list was empty. Temporary viewports reset; separate QA tab closed; existing played game tab retained without resetting progress.
- Actual screenshots include street/CNG, character/rickshaw, opposite rickshaw view, bus/divider and mobile settings/game/Bengali proof. Wheel zoom's controlled native-input check remains incomplete because native window activation failed; implementation alone is not recorded as a passed input test.

Art remains stylized; final semi-realistic art acceptance and real-device performance remain open. No Phase 02–06 features were started.

## Phase 00–01 resumption and interrupted final QA — 2026-11-02

Read-only audit confirmed `D:/neta-udche -3d` is the existing standalone `neta-uthche` game, not clothing commerce. Git reports no repository. Preserved existing instructions/goals/specs/source/data. Context7 rechecked official Babylon/Havok/Vite APIs; normal-network npm metadata matched installed Babylon 9.33.1, Havok 1.3.14 and Vite 8.3.5. Initial restricted-network failure was resolved with read-only normal-network access. Production preview on 4173 returned HTTP 200 and the game HTML.

Added elapsed-frame-time FPS statistics/reset/test, Bengali camera distance buttons, motion diagnostics and text-selection prevention. Corrected merged static shadow casting to preserve original caster intent and froze static world matrices. Close art inspection found white box biscuit props; replaced their source with transparent lathed jars, biscuit stacks/tin lids, stove details and framed distant windows. Latest final-source verify passed types, lint, seven tests and production build (`harness/evidence/phase01-recheck-checks.txt`). No new runtime dependency or later-phase implementation.

Before that final prop-only edit, actual desktop gameplay with the same camera/movement/physics code showed Walk/Run/Pickup/Throw, +5 egg and +8 sandal rewards, counter collision at x=-5.699025 and awning camera retraction to about 1.5446 m target distance from a nominal 4.8 m. Three angle images and JSONs are in `harness/evidence/phase01-review`. The initial out-of-range pickup attempt failed as expected; it is not a passed collection. Time-weighted desktop samples measured 23.59 and 23.26 FPS over 600 frames, with background/occlusion throttling also observed; do not reuse prior higher FPS as a current stable-performance pass.

Latest prop build reached Bengali HUD in Chrome/IAB, but final prop appearance and fresh mobile/preset/shaping/three-angle regression were interrupted. IAB preview was opened in the Codex panel after background throttling; the user agreed to keep it in front. Browser calls then timed out. After explicit session reset, inventory reported: user stopped Computer Use with physical Escape; do not make further Computer Use calls. UI work stopped at that point. Temporary 1280x720 overrides could not be reset/verified after the interruption. Existing played game state was not reset/deleted.

See `harness/phase-01-review.md` for accurate current acceptance status, file list, provenance and remaining work. **Phase 01 is not complete or visually approved.** Final mobile/visual/performance gates remain open. No Phase 02–06 work started.

## Authorized A–H expansion and audio A — 2026-11-03

The latest request in `harness/context/004-expansion-request.md` and the user's updated AGENTS instructions authorize incremental A–H expansion, superseding the earlier Phase 00–01-only boundary. Read-only inspection found the existing standalone game, not commerce; no Git repository. Preserved the working slice and archived source at `assets/source/archive/pre-expansion-20261102-230305.zip`. No database or unrelated project touched. Current Context7 Babylon/Havok/Vite/Colyseus references were checked during expansion preparation; no Colyseus runtime dependency or later multiplayer implementation was installed.

Milestone A integrates nine persisted audio buses, gesture unlock, eight animation-contact footstep surfaces, spatial attenuation/occlusion, randomized Dhaka ambience, five music contexts/crossfades and Bengali audio/music administration. The native local server persists draft/public/history atomically, validates audio uploads and separates unpublished previews from public delivery. Review fixed published continuous-loop changes, pause/preload/preview races, handedness, finite playlists, repetition counting, rollback draft loss, monotonic revisions, incidental MP3 sync-byte acceptance and public caching of unpublished files. Existing data/history retained.

65 original Foley/music files are generated from editable source. 23 additional fictional Bengali clips use the official Piper bn_BD model, with the full model card, CC BY-SA/CMU notices and per-line provenance retained. The legacy 2023 CLI failed on the current multi-codepoint phoneme map; current official Piper Python 1.8.0 generated the clips without changing the model. No real politician/party recording, identity imitation or commercial song was added. Human intelligibility/mix review is still open.

### Final source checks and service evidence

- Final `npm run verify`: typecheck, lint, **20/20 tests**, game build and Admin build passed. `harness/evidence/expansion/milestone-a-checks.txt`. Tests include actual local API persistence/upload/publish/rollback/draft restore/restart, 7 reproducible audio graph regressions and preserved gameplay/asset/Bengali checks. The large 3D chunk advisory remains; no build failure.
- Production localhost4300 and isolated QA4301 run the new builds. The primary Admin remains unconfigured; its password belongs to the user. Only separate QA data/accounts/uploads were used for browser publishing. Read-only `server-production-probe.json`: both health/content 200, all 88 public audio assets and all 371 JS chunks 200, exact current-dist entry JS byte match, Bengali fonts/GLB/calibration/HDR/Havok/vehicle textures and Admin assets 200. WAV range delivery 206. This is service delivery, not gameplay observation.

### Actual rendered observations

- Before gesture: AudioContext not started, unlocked=false, RMS=0. After click: running, published catalog, actual RMS>0, exploration music and traffic/CNG active. Muting master produced RMS=0; unmuted later samples had nonzero output. Music slider set to 0.23 persisted after reload. `before-gesture.json`, `after-gesture.json`, `master-muted.json`, `reloaded-settings.json`.
- Walk moved player from z=-9 to -6.4953 with contacts near 15/45 of its 60-frame cycle; Run reached z=0.3249 with contacts near 10/30 of its 40-frame cycle. Actual Walk/Run/Pickup/Throw observed. Six eggs collected; one physical throw consumed an egg, awarded 5, registered a hit and reduced target to 75. Audio events pickup/throw/egg/hit/firstHit observed. `walk-desktop.json`, `run-contact.json`, `egg-hit.json`. The walk filename predates discovering that the actual viewport remained 597×646; it is not proof of a 1280×720 desktop check.
- Real Admin form uploaded an authorized Bengali speech WAV, and music HTML preview reported paused=false. Saving changed music retained public revision1/asset music-exploration/volume0.55. Publishing reached the already running game as revision4/asset music-chase/configuredVolume0.11. Rollback reached revision6/original asset/volume0.55. Restoring saved draft5 recovered “অপ্রকাশিত খসড়ার বাংলা সুর” while game stayed revision6. `draft-unpublished.json`, `admin-published-in-game.json`, `admin-rollback.jpg`, `rollback-in-game.json`. Runtime refresh control used; game not recreated for publication.
- Actual 597×646, desktop profile with HDR/AO: 600 visible frames over9999.5ms ≈60.00FPS. Brief later snapshots 58–61FPS. This is neither a 1280×720 benchmark nor Android qualification. The Bengali HUD/subtitles were read at the observed size. Two current gameplay angles: `gameplay-front.png`, `gameplay-cng.png`. Existing stylized artwork is not newly claimed as final semi-realistic art acceptance.

### Remaining gate and exact blocker

IAB accepted requested viewport overrides but DOM/screenshot stayed597×646. A Chrome fallback later returned `Debugger unattached`; calls timed out/reset. Native Chrome was minimized, then state capture and window listing timed out after activation. IAB later timed out dispatching a click while opening Settings, leaving its immediate interaction state unknown; a later read showed Settings open but took about34s and reported12FPS. Dedicated current-build desktop/mobile layouts, fresh mobile controls/FPS, night/third-angle regression, blocked/resume/additional-surface footstep runtime and auditory review remain open. Latest label-only source rebuild is verified by tests/service probes, not a new rendered pass. Temporary viewport reset completed after connection recovery. The existing played primary tab was marked to remain open without resetting its progress.

**A is not complete. B–H have not been implemented.** Read-only B preparation identified safe published spawn validation, action-driven tutorial, control conflicts and original boarding clips as prerequisites. Do not jump past A's acceptance or rebuild the working systems on resume. Full current matrix, evidence and resumption tasks: `harness/milestone-a-review.md`.

The user subsequently confirmed restarting the browser test connection. Chrome inventory and session naming succeeded, but binding the existing game again returned `Debugger unattached`; creating/navigating a fresh test tab timed out and reset the tool session. A's rendered gate remains open after this concrete recovery attempt. No completion or new permission requirement is inferred from that failure.

## Milestone A gate passed; B next — 2026-11-03

Recovered the local services and selected-preview workflow. The services had stopped; restarted owned hidden Node processes on4300/4301 with exactly the existing data directories, then actual game rendering recovered. Process IDs/start evidence are in `service-processes.json`; no data reset. QA preview is retained for ongoing work and temporary viewport overrides were reset after A testing.

The user's in-game voice report was a real defect. Dry `voice-spawn-0.wav` was clear to the user; runtime fixes corrected category auditions that played a menu beep, simultaneous same-hit voice cutoffs, stop-before-decode replacement, feet-level emitters and generic subtitles overwriting spoken lines. User subsequently reported revised impact speech clear. `voice-user-review.json` records exact scope of that feedback. No alternative TTS service/model was installed.

Actual mobile390×844 verification exposed a horizontal settings scrollbar; corrected range/grid intrinsic widths and verified page scrollWidth390 and dialog scrollWidth=clientWidth344. All9 volume values and4 independent mutes changed through real controls, persisted identically after reload and were restored identically. Actual touch joystick, egg/sandal pickup and both physical throws passed: egg+5/target75, sandal+8/total13/target35. Actual hit had one voiced reaction. Idle, blocked motion and pause/resume had no stale player steps; paused input did not move the player and suspended context later returned running.

Observed all8 mapped surfaces across the A regression passes. First dirt/metal/brick/mud encounters on the latest audio code played after prewarming all24 small footstep files; a slow-decode bootstrap regression prevents loss of first contacts. Asphalt/Walk/Run, concrete, shop and puddle contacts are also recorded. Earlier inconclusive attempts remain unchanged.

Camera regression found at tea-shop grazing position[-5.7403,.34,-1.0851]: unregistered side/backwall/column geometry hid the player. Added camera-only padded bounds from actual authored meshes before batching. Real reproduction now retracts camera to[-5.7382,2.0955,-2.9057] with visible player from position[-5.7382,.34,-1.0255], nominal4.8m follow distance. Walk/Havok obstacles unchanged. A separate centre-drag failure was the decorative crosshair intercepting pointer events; CSS pass-through now gives actual yaw0→0.7. Both defects were observed and fixed, not written off as tool failures.

Final source `npm run verify`: **types, lint,28/28 tests, game/Admin production builds passed**. Last crosshair-only CSS edit received a successful fresh production build and actual gesture regression. Final loaded entry`index-SdHMXPBR.js`/CSS`index-DHztAZe9.css` matches current disk and live delivery. Current compact service probe is `server-production-probe-final.json`; previous stopped/failed probes remain historical.

Final measured1280×720 Desktop: **59.9976FPS**,600 frames/10000.4ms, HDR/AO. Final390×844 Mobile profile on thisPC: **60.00FPS**,600/10000ms, AOoff. Separate active mobile interaction sample56.99FPS; older lower samples remain recorded. These are short viewport tests, not Android hardware or every-location qualification. Bengali shaping sample visually inspected in both sizes, no replacement/Devanagari letters or horizontal overflow. Three final actual angles: `final-day-street.png`, `final-day-cng.png`, `final-evening-rickshaw.png`; additional counter, Admin, settings and mobile/shaping images retained.

**A's implemented audio acceptance gate passes. B is next; B–H gameplay is not yet implemented.** Existing artwork remains stylized, final semi-realistic art acceptance and real-phone qualification are still open. Future vehicle/mission/news audio events are not claimed as later gameplay. Definitive matrix and limits: `harness/milestone-a-acceptance.md`. B preparation only: `harness/build/milestone-b.md`.

## Milestone B implementation started — 2026-11-03

Inspected the fixed start position, six existing rig clips, movement/camera listeners, small static map, globally batched parked CNG and isolated audio service before extending them. Accepted A source/model/config is archived in `assets/source/archive/milestone-a-accepted-20261103.zip`; local content directories are excluded and unchanged.

Affected systems: shared trusted spawn/tutorial rules, isolated spawn publication delivery, game input/state/UI, the existing parked CNG's anchors/batching and three additional clips on the original rig. Principal regressions to check: safe full-footprint placement; gesture drag versus use; pause/tutorial input clearing; A's calibrated footsteps/voice fixes; camera follow while boarding; collision-safe animated entry/exit; responsive map/tutorial controls; vehicle draw-call increase and preservation of original clips. Full driving/traffic and later Admin modules remain outside B.

B uses validated trusted shipped spawn provenance as its staged default registry; it does not turn a client-provided flag into Admin approval or require the user to create a production password before playing. Full authenticated spawn editing/publication and its acceptance belong to G. One parked CNG interaction/entry/exit is required by B's tutorial; this is not E driving completion.

Implementation and focused tests are in progress. **B is not complete.** Actual ten-step desktop/mobile tutorial, preference/replay, random-spawn safety and animated boarding runtime gates remain required before C.

## Milestone B implementation and partial runtime evidence — 2026-11-03

Implemented the finite trusted factory spawn registry and isolated published read, full-footprint world/occupancy checks, Bengali blocked-start retry, ten-action tutorial state machine, expanded map, persisted Skip/don't-show/completion preferences and Settings replay. Replay retains the current position, inventory and score. Original CNG geometry now retains real doorway/seat/exit anchors and occupancy; original entry/seated/exit clips extend the existing six-motion rig. Doorway rotation is speed-limited, stationary alignment uses Idle, and grounded entry/exit endpoints avoid a curb-height pop. Dynamic entry/exit obstruction freezes at the last safe pose and animation time. Full driving and the G spawn editor remain deferred; factory content is not misreported as an observed Admin publication.

Mobile run is a real toggle (`g.run()`, `runEnabled`, `aria-pressed`) so one hand can enable it and then move the joystick. Toggling without movement does not pass the run lesson. Desktop controls include Tab boarding, M map, Enter/click use and wheel item selection, with drag/use separation and dialog focus handling.

`harness/evidence/milestone-b/verify.txt` records **typecheck, lint, 53/53 tests and game/Admin production builds passing before the latest spawn/QA-fixture changes**. Final-source checks must be rerun. Tests include trusted spawn/service isolation, tutorial false-progress/preference behavior, original rig/clip preservation and continuous collision-safe boarding, blocked alternate exits, obstruction pause/resume and ground-height convergence. `boarding-tests.txt` records the focused ten-test controller pass; this is automated evidence, not visual animation acceptance.

Actual 1280×720 desktop playback completed all ten tutorial steps through real controls, including collection, explicit selection, an Enter-triggered physical sandal throw, +8 score, CNG entry/seated state, blocked seated movement/use and animated exit before selecting the first mission marker. `desktop-tutorial.json` ends at stepIndex10/status completed; the registry was revision1/source factory/origin server-factory. Screenshots include `desktop-tutorial-start.png`, `desktop-map.png`, `desktop-cng-seated.png`, `desktop-cng-side.png` and `desktop-tutorial-completed.png`.

Earlier actual 390×844 mobile playback observed joystick movement and camera swipe (`mobile-tutorial.json`). Preview tabs were then closed/recreated; later `final-mobile-tutorial.json` observations measure **354×767**, not 390×844. The final complete mobile action chain remains pending. These local-PC viewport observations do not establish Android performance. A deliberately visible, initially disabled Bengali rail fixture was added for a genuine blocked-exit/retry browser check; that acceptance must still be observed rather than inferred from unit tests.

**B remains ACTIVE and is not complete. C has not started.** Remaining gates include final mobile chain, blocked-exit retry, final spawn/replay/preference and A regressions, current-build FPS/three-angle evidence and final-source verification. Existing stylized art is not claimed as final semi-realistic visual approval; user audio/content data are preserved.

## Milestone B final mobile chain; acceptance still open — 2026-11-03

Fresh `verify-final.txt` passes typecheck, lint, **57/57 tests** and both production builds, producing game entry `index-CmxIvYoq.js` and CSS `index-hKJLPJH0.css`. Actual final mobile sequence is now complete at measured390×844, page scrollWidth390: `accepted-mobile-chain.json` records all ten actions through visible buttons, joystick and scene swipe, ending stepIndex10/status completed. The physical egg throw consumed6→5, registered one hit, awarded5 and reduced target health100→75.

With the deliberately visible Bengali rail fixture enabled, the actual exit attempt remained seated at exactly[4,.3400000036,2.6700000763], step8. Disabling the fixture allowed the observed ExitVehicle clip and safe onFoot landing[2.6199998856,0,1.9199999571], step9, then mission-marker completion. `verified-blocked-exit.png`, `verified-mobile-exit-animation.png`, `verified-mobile-seated.png` and `verified-mobile-completed.png` retain rendered proof. The QA fixture is not enabled in ordinary gameplay.

Mobile map overflow was observed and corrected: `mobile-map-fixed.json` measures width366.2744px at x11.9927 inside390px; clientWidth=scrollWidth365. A later Settings replay preserved score5, eggs5 and the exact landing position; Skip retained those values and released tutorial safety. The don't-show checkbox is true in the skipped snapshot, but reload persistence was not yet observed at this audit. `final-mobile-tutorial.json` retains those exact labels and earlier differently sized attempts rather than overwriting their history.

The final mobile completion snapshot records600 visible frames/10000.1ms=59.9994FPS with mobile profile/AO off. This is a short local-PC viewport sample, not Android qualification. Read-only assertions of source JSON/build values are in `acceptance-draft-audit.json`. `harness/milestone-b-acceptance.md` is an explicit draft with remaining latest-build desktop/performance/preference-reload/spawn/server-hash/A-regression checks. **B is not complete and C has not started.**

## Milestone B implementation finished; final acceptance blocked — 2026-11-04 (Asia/Dhaka)

Latest `verify-final.txt` records **typecheck, lint,60/60 tests and both production builds passing**, entry `index-Bol4r5V1.js`, CSS `index-hKJLPJH0.css`. Full desktop1280×720 and mobile390×844 ten-action tutorial chains were actually completed on CmxIvYoq; exact `verified-desktop-*`/`verified-mobile-*` labels and accepted-chain JSON preserve those observations. Preference reload now has direct evidence: don't-show persisted with tutorial closed, master mute persisted and settings were restored. Replay/Skip preserved the prior live position, score and inventory.

Targeted DYjhqTCn camera regression corrected a tight counter view: resolved camera~.049884m hides the body (opacity0); open view restores it (~.9808 at4.736m, then~1 at5.002m); normal seated CNG view remains opaque at3.818m. Actual counter collision produces no phantom player footsteps; pause clears controls; civilian hit gives no score and costs health100→92. Three actual camera-build angles are `final-desktop-tea-shop.png`, `final-desktop-cng-seated-opaque.png` and `final-desktop-evening-rickshaw.png`. These are not relabeled as latest spawn-only build captures.

Actual A Admin regression published revision8/music-chase/.11 into the already running game, rolled back to9/music-exploration/.55, and restored draft10 to baseline7 configuration with new audit/history retained. `audio-qa-restored.json` and final production probe confirm primary hash unchanged and QA configuration restored. Both4300/4301 serve final entry/dynamic game/CSS/952896-byte GLB with matching hashes in `production-probe-final.json`. QA files/revisions intentionally include the new audit entries; no byte-identity claim is made for QA.

A real idle-start defect was found: an NPC could later walk into a point safe at the first frame. Final Bol4r5V1 now excludes the whole authored patrol sweep. Automated checks sample721 positions across each full19.635s cycle and multiple initial clocks/phases. Of6 registered factory entries, **3 are currently eligible: west-south, east-south, west-middle**. Five earlier real starts yielded4 unique points before that final sweep exclusion (`actual-random-spawns.json`); they do not prove6 eligible or a latest-build idle-cycle pass.

Earlier meaningful foreground samples remain scoped: CmxIvYoq mobile600/9999.5ms=60.0030FPS; DYjhqTCn desktop600/10000.6ms=59.9964FPS, seated600/10116.4ms=59.3096FPS. The latest recovered preview backgrounds near1FPS. The user explicitly cannot keep it foreground, so dependent animation/idle-cycle/FPS testing stopped. **Bol4r5V1 still lacks a rendered full idle-cycle and foreground performance acceptance.** Older high samples are not substituted for it; background samples are not performance qualification.

Fresh `bengali-script-audit-final.json` resolves earlier broad-block `badGlyphs:true` flags: the actual390×844 DOM has no Devanagari-script characters or U+FFFD, uses Noto Sans Bengali, and the only broader-block character is shared Common-script Bengali danda`।`U+0964. Earlier files remain intact. The smaller saved shaping samples were independently audited in `bengali-text-audit-corrected.json`, with its narrower scope recorded.

`harness/milestone-b-acceptance.md`, README, GOALS and PLANS now record **implementation done, B ACTIVE with acceptance pending**. This is an external foreground-testing blocker, not a formal goal pause or completion. **C has not started.** Existing art remains stylized and real Android performance/final semi-realistic visual approval remain open.

## Milestone B functional scope verified; C ready — 2026-11-04 (Asia/Dhaka)

The user authorized restoring/focusing the Chrome QA window through window management. This resolved the earlier foreground-testing blocker without changing power preferences or controlling another project. Actual `windowFocused:true` records strengthen the visibility evidence; `pageVisible:true` alone had not distinguished an occluded IAB. The previous blocked report remains historical, not deleted.

Resumption build `index-CSdJS6tH.js` adds only the read-only `simulationTime` diagnostic. `verification-resume-checks.txt` passes types, lint, **60/60 tests** and both production builds. On measured1280×720/Desktop/HDR/AOon, actual simulation time169.7261→196.6821 covers26.956s, exceeding the full19.634954s patrol cycle. Across saved observations, player[-6.3,.2,-16] stays exactly fixed, controls remain cleared, four civilian patrols move2.512–2.953m and nearest NPC centre remains at least7.5420m away, above the1.0m combined clearance. `resumed/desktop-idle-cycle-timed.json` and independent assertions record this final spawn observation.

Actual focused desktop samples (`desktop-foreground.json`) have windowFocused/pageVisible true; final600frames/20178.7ms=**29.7343FPS**, with full-window range29.5331–29.9150. The final frame window fits inside31.494s observed focus span. **The global60FPS desktop target is unmet on this observed run.** Older~60FPS samples are not substituted for it or used to label this a performance pass.

At measured390×844/Mobile/HDR/AOoff, actual simulation471.1926→502.1718 covers30.9792s with the same fixed player and cleared controls. Four civilians move2.555–2.986m; minimum saved NPC distance7.6940m. Seven focused records include early warmup (first10frames) and three full600-frame windows. Final600/19999.6ms=**30.0006FPS**, fitting inside31.173s observed focus span. This is a local-PC mobile viewport, **not real Android30FPS qualification**. `resumed/mobile-independent-audit.json` and `desktop-independent-audit.json` recompute the raw values without engine injection.

`resumed/hardware.json` records Intel Core5 210H, Intel Graphics with60Hz refresh and9% battery while discharging. Those facts do not establish the cause of~30FPS; no power setting was changed. Renderer/browser/display/power conditions should be profiled as the world expands. The global60FPS desktop target and Android qualification remain explicit project requirements. B's own tutorial/spawn criteria and shared verification require actual measurement, without a numeric B-specific threshold.

**B's scoped functional acceptance now passes**: prior actual ten-step desktop/mobile tutorial, boarding/blocked-exit, replay/preferences, Unicode/map and A regression evidence remains valid, with final patrol safety and genuine focused measurements now observed. This is **not a performance pass or complete A–H game**. Acceptance, README, B specification, GOALS and PLANS now distinguish those scopes. C specification is READY; C gameplay is not yet implemented. Preserve the accepted B source backup and existing data/history before authorized sequential C work.
