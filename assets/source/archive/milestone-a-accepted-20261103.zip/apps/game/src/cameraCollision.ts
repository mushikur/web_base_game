import type { AbstractMesh } from "@babylonjs/core/Meshes/abstractMesh.js";
import { MeshBuilder } from "@babylonjs/core/Meshes/meshBuilder.js";
import type { Scene } from "@babylonjs/core/scene.js";

export type CameraObstacle = {
  name: string;
  x: number;
  y: number;
  z: number;
  w: number;
  h: number;
  d: number;
};

/** Capture authored geometry before static batching disposes its source mesh. */
export function cameraBounds(mesh: AbstractMesh): CameraObstacle {
  mesh.computeWorldMatrix(true);
  const { minimumWorld: min, maximumWorld: max } =
    mesh.getBoundingInfo().boundingBox;
  return {
    name: mesh.name,
    x: (min.x + max.x) / 2,
    y: (min.y + max.y) / 2,
    z: (min.z + max.z) / 2,
    w: max.x - min.x,
    h: max.y - min.y,
    d: max.z - min.z,
  };
}

/** The camera has a near plane, so a centre ray alone may graze a visible wall. */
export function cameraCollider(scene: Scene, bounds: CameraObstacle) {
  const clearance = 0.25;
  const mesh = MeshBuilder.CreateBox(
    `Hidden camera collider ${bounds.name}`,
    {
      width: bounds.w + 2 * clearance,
      height: bounds.h + 2 * clearance,
      depth: bounds.d + 2 * clearance,
    },
    scene,
  );
  mesh.position.set(bounds.x, bounds.y, bounds.z);
  mesh.computeWorldMatrix(true);
  mesh.visibility = 0;
  mesh.isPickable = false;
  mesh.metadata = { staticBatchExclude: true };
  return mesh;
}
