import {
  AbstractMesh,
  Color3,
  Color4,
  Curve3,
  DynamicTexture,
  Mesh,
  MeshBuilder,
  PBRMaterial,
  Scene,
  ShadowGenerator,
  StandardMaterial,
  TransformNode,
  Vector3,
} from "./engine";
import {
  hex,
  material,
  random,
  signTexture,
  texture,
  weathered,
  rickshawArt,
} from "./art";
export type Obstacle = {
  x: number;
  z: number;
  w: number;
  d: number;
  h?: number;
};
export type World = {
  obstacles: Obstacle[];
  lamps: Mesh[];
  buildings: Mesh[];
  shadow: ShadowGenerator;
};
export function createWorld(scene: Scene, shadow: ShadowGenerator): World {
  const obstacles: Obstacle[] = [],
    lamps: Mesh[] = [],
    buildings: Mesh[] = [];
  const asphalt = weathered(
      scene,
      "Cracked aggregate asphalt",
      "#555752",
      "road",
    ),
    concrete = weathered(scene, "Old pavement", "#ac9f85"),
    cream = weathered(scene, "Lime plaster", "#bdab89"),
    ochre = weathered(scene, "Ochre plaster", "#c29459"),
    teal = weathered(scene, "Faded green plaster", "#617e72"),
    pink = weathered(scene, "Old rose plaster", "#ac8977"),
    brick = weathered(scene, "Red brick", "#8e5943"),
    wood = weathered(scene, "Tea stall wood", "#67452b", "wood");
  const black = material(scene, "Painted iron", "#252e2b", 0.68, 0.4),
    yellow = material(scene, "Faded curb yellow", "#d9af3d"),
    glass = material(scene, "Dark blue window glass", "#263f43", 0.22, 0.32),
    steel = material(scene, "Galvanized roof", "#86928d", 0.58, 0.68),
    red = material(scene, "Terracotta", "#9f4c35"),
    paper = material(scene, "Old paper", "#d9c6a1"),
    rubber = material(scene, "Tire rubber", "#242927"),
    chrome = material(scene, "Wheel steel", "#9ca39d", 0.35, 0.8);
  function box(
    n: string,
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    m: PBRMaterial,
    cast = false,
  ) {
    const b = MeshBuilder.CreateBox(
      n,
      { width: w, height: h, depth: d },
      scene,
    );
    b.position.set(x, y, z);
    b.material = m;
    b.receiveShadows = true;
    if (cast) shadow.addShadowCaster(b);
    return b;
  }
  function post(
    n: string,
    a: Vector3,
    b: Vector3,
    r: number,
    m: PBRMaterial,
    parent?: TransformNode,
  ) {
    const length = Vector3.Distance(a, b);
    const mesh = MeshBuilder.CreateCylinder(
      n,
      { height: length, diameter: r * 2, tessellation: 10 },
      scene,
    );
    mesh.position = Vector3.Center(a, b);
    mesh.rotationQuaternion = null;
    const dir = b.subtract(a).normalize();
    mesh.rotation.z = -Math.atan2(dir.x, dir.y);
    mesh.rotation.x = Math.atan2(dir.z, Math.hypot(dir.x, dir.y));
    mesh.material = m;
    if (parent) mesh.parent = parent;
    return mesh;
  }
  function label(
    text: string,
    sub: string,
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    angle: number,
    bg?: string,
  ) {
    const p = MeshBuilder.CreatePlane(
      text,
      { width: w, height: h, sideOrientation: Mesh.DOUBLESIDE },
      scene,
    );
    p.position.set(x, y, z);
    p.rotation.y = angle;
    const m = new StandardMaterial(text, scene);
    m.diffuseTexture = signTexture(scene, text, sub, bg);
    m.emissiveColor = new Color3(0.19, 0.16, 0.11);
    m.specularColor = Color3.Black();
    p.material = m;
    return p;
  }
  box("Road foundation", 0, -0.16, 3, 46, 0.3, 70, asphalt);
  const ground = MeshBuilder.CreateGround(
    "Distant ground",
    { width: 230, height: 230 },
    scene,
  );
  ground.position.y = -0.32;
  ground.material = concrete;
  for (const s of [-1, 1]) {
    box("Raised footpath", s * 7, 0.06, 3, 3.1, 0.25, 48, concrete);
    obstacles.push({ x: s * 12, z: 2, w: 8, d: 48, h: 18 });
    for (let z = -20; z < 27; z += 1.35) {
      box(
        "Black yellow curb",
        s * 5.43,
        0.16,
        z,
        0.27,
        0.32,
        1.3,
        Math.round(z / 1.35) % 2 ? black : yellow,
      );
    }
    for (let z = -20; z < 27; z += 2.5) {
      box("Pavement joint", s * 7, 0.192, z, 3, 0.012, 0.025, black);
    }
  }
  for (let z = -18; z < 24; z += 6)
    box("Worn road lane mark", 0, 0.007, z, 0.09, 0.011, 2.8, paper);
  // Reflective shallow puddles with irregular outlines, rather than opaque blue discs.
  const wet = material(
    scene,
    "Water dark asphalt reflection",
    "#697c78",
    0.13,
    0.35,
  );
  wet.alpha = 0.58;
  for (const [x, z, sx, sz] of [
    [-3, -6, 1.4, 0.55],
    [3, 8, 0.8, 1.3],
    [-2, 15, 1.2, 0.5],
    [4, -13, 0.6, 0.9],
  ]) {
    const shape = Array.from(
      { length: 18 },
      (_, i) =>
        new Vector3(
          Math.cos((i / 18) * 6.283) * (1 + random() * 0.25) * sx,
          0,
          Math.sin((i / 18) * 6.283) * sz,
        ),
    );
    const positions = shape.flatMap((v) => [v.x + x, 0.016, v.z + z]);
    positions.unshift(x, 0.016, z);
    const indices = [];
    for (let i = 1; i <= 18; i++) indices.push(0, i, i === 18 ? 1 : i + 1);
    const mesh = new Mesh("Shallow road puddle", scene);
    mesh.setVerticesData("position", positions);
    mesh.setIndices(indices);
    mesh.material = wet;
  }
  // Recessed openings, lintels, balconies, grilles and damp walls make each facade architectural.
  const colors = [ochre, teal, cream, pink, brick];
  for (const side of [-1, 1])
    for (let i = 0; i < 6; i++) {
      const z = -17 + i * 8.2,
        w = 7.5,
        height = 8 + (i % 3) * 2.8,
        x = side * 11.5,
        front = side * 8.0;
      if (side === -1 && i === 2) continue;
      const body = box(
        "Weathered concrete apartment",
        x,
        height / 2,
        z,
        7,
        height,
        w,
        colors[(i + (side > 0 ? 2 : 0)) % 5],
        true,
      );
      body.checkCollisions = true;
      buildings.push(body);
      box("Roof parapet", x, height + 0.22, z, 7.2, 0.45, w + 0.2, cream, true);
      box(
        "Street level lintel",
        front - side * 0.06,
        3,
        z,
        0.36,
        0.22,
        w,
        cream,
      );
      const floors = Math.floor(height / 2.6);
      for (let f = 0; f < floors; f++)
        for (let col = -1; col <= 1; col++) {
          const zz = z + col * 2.2,
            yy = 1.55 + f * 2.6;
          box(
            "Deep window recess",
            front - side * 0.025,
            yy,
            zz,
            0.11,
            1.65,
            1.46,
            black,
          );
          box(
            "Glass window",
            front - side * 0.09,
            yy,
            zz,
            0.13,
            1.45,
            1.26,
            glass,
          );
          box(
            "Window centre mullion",
            front - side * 0.18,
            yy,
            zz,
            0.12,
            1.5,
            0.055,
            cream,
          );
          box(
            "Window sill",
            front - side * 0.2,
            yy - 0.83,
            zz,
            0.45,
            0.12,
            1.65,
            cream,
          );
          if (f > 0) {
            box(
              "Balcony floor",
              front - side * 0.6,
              yy - 0.87,
              zz,
              1.1,
              0.14,
              1.9,
              cream,
              true,
            );
            box(
              "Balcony top rail",
              front - side * 1.04,
              yy - 0.1,
              zz,
              0.065,
              0.055,
              1.85,
              black,
            );
            for (let b = -3; b <= 3; b++)
              box(
                "Balcony vertical grille",
                front - side * 1.04,
                yy - 0.48,
                zz + b * 0.26,
                0.045,
                0.76,
                0.035,
                black,
              );
          }
          if ((f + col + i) % 3 === 0) {
            const ac = box(
              "Air conditioner",
              front - side * 0.3,
              yy + 0.37,
              zz + 0.7,
              0.5,
              0.43,
              0.58,
              steel,
            );
            for (let sl = 0; sl < 4; sl++)
              box(
                "AC grille",
                ac.position.x - side * 0.26,
                yy + 0.22 + sl * 0.08,
                zz + 0.7,
                0.01,
                0.025,
                0.46,
                black,
              );
          }
        }
      for (let f = 1; f < floors; f++)
        box(
          "Concrete floor band",
          front - side * 0.12,
          f * 2.6 + 0.08,
          z,
          0.3,
          0.14,
          w,
          cream,
        );
      const shops = [
        "শেষ কাপ গণতন্ত্র",
        "মায়ের দোয়া ফার্মেসি",
        "তাজা সবজির বাজার",
        "নতুন সকাল স্টুডিও",
        "মামা ভ্যারাইটিজ",
        "মেরামত ঘর",
      ];
      label(
        shops[i],
        "প্রতিশ্রুতি মোড় • ঢাকা",
        front - side * 0.3,
        2.8,
        z,
        5.9,
        0.82,
        (side * Math.PI) / 2,
        i % 2 ? "#772d2a" : "#22463e",
      );
      // Grimy corrugated shop shutter with individual slats.
      for (let zz = z - 2.7; zz < z + 2.7; zz += 0.19)
        box(
          "Shop shutter slat",
          front - side * 0.2,
          1.3,
          zz,
          0.07,
          2.4,
          0.18,
          steel,
        );
      if (i % 2 === 0) {
        box("Roof water tank", x, height + 1.0, z, 2, 1.45, 1.7, black);
        post(
          "Tank water pipe",
          new Vector3(x, height + 0.8, z),
          new Vector3(front, height + 0.8, z),
          0.04,
          black,
        );
      }
    }
  // Back street bend: brickwork and roofs close the sight line without a flat backdrop.
  for (let i = 0; i < 4; i++) {
    const x = -15 + i * 9;
    box(
      "Distant street block",
      x,
      5 + (i % 2),
      31,
      8,
      10 + (i % 2) * 3,
      8,
      colors[i],
      true,
    );
    for (let j = 0; j < 3; j++)
      for (let f = 0; f < 3; f++)
        box(
          "Distant window",
          x - 2.5 + j * 2.5,
          2 + f * 2.7,
          26.95,
          1.2,
          1.5,
          0.06,
          glass,
        );
  }
  // কেটলি কেবিনেট — open tea shop with service shelf, bench, stove, cups and kettle.
  const tx = -8.7,
    tz = 0;
  box("Tea shop brick back", -11.3, 1.6, tz, 0.28, 3.2, 7.2, brick, true);
  box("Tea shop floor", tx, 0.22, tz, 5.7, 0.22, 7.2, concrete);
  for (const zz of [-3.6, 3.6]) {
    box("Tea shop brick side", tx, 1.3, zz, 5.7, 2.6, 0.21, ochre, true);
    post(
      "Tea shop front column",
      new Vector3(-5.75, 0.2, zz),
      new Vector3(-5.75, 3.4, zz),
      0.06,
      black,
    );
  }
  for (let z = -3.9; z < 4; z += 0.22) {
    const roof = box(
      "Corrugated tin roof",
      tx,
      3.58,
      z,
      6.6,
      0.075,
      0.2,
      steel,
      true,
    );
    roof.rotation.z = -0.06;
  }
  label(
    "কেটলি কেবিনেট",
    "গরম চা, ঠান্ডা প্রতিশ্রুতি",
    -5.38,
    3.15,
    0,
    6.85,
    1.0,
    -Math.PI / 2,
    "#20594a",
  );
  label(
    "চা ১০ টাকা",
    "বাকির খাতা বন্ধ",
    -11.1,
    2.1,
    -1.7,
    2,
    0.9,
    -Math.PI / 2,
    "#7b302b",
  );
  box("Tea service counter", -6.7, 0.95, 0.2, 1.0, 1.42, 5.8, wood, true);
  box("Counter stone top", -6.7, 1.7, 0.2, 1.2, 0.1, 6.0, concrete);
  obstacles.push({ x: -6.7, z: 0.2, w: 1.25, d: 6, h: 1.75 });
  box("Bench seat", -9.5, 0.6, -2.8, 2.5, 0.16, 0.48, wood, true);
  for (const x of [-10.4, -8.6])
    box("Bench legs", x, 0.31, -2.8, 0.1, 0.55, 0.4, black);
  const cupMat = material(scene, "Tea cup ceramic", "#ded5b6", 0.28),
    teaMat = material(scene, "Tea in cup", "#673515", 0.4);
  for (let i = 0; i < 9; i++) {
    const x = -6.65 + random() * 0.4,
      z = -2 + i * 0.55;
    const cup = MeshBuilder.CreateCylinder(
      "Small tea glass",
      {
        height: 0.14,
        diameterTop: 0.095,
        diameterBottom: 0.065,
        tessellation: 14,
      },
      scene,
    );
    cup.position.set(x, 1.81, z);
    cup.material = cupMat;
    const tea = MeshBuilder.CreateDisc(
      "Tea surface",
      { radius: 0.04, tessellation: 14 },
      scene,
    );
    tea.rotation.x = Math.PI / 2;
    tea.position.set(x, 1.883, z);
    tea.material = teaMat;
  }
  const kettle = MeshBuilder.CreateLathe(
    "Aluminium kettle body",
    {
      shape: [
        new Vector3(0.06, 0, 0),
        new Vector3(0.22, 0.05, 0),
        new Vector3(0.24, 0.23, 0),
        new Vector3(0.17, 0.3, 0),
        new Vector3(0.17, 0.32, 0),
        new Vector3(0, 0.34, 0),
      ],
      tessellation: 28,
    },
    scene,
  );
  kettle.position.set(-6.65, 1.76, 1.3);
  kettle.material = chrome;
  post(
    "Kettle spout",
    new Vector3(-6.5, 1.86, 1.3),
    new Vector3(-6.24, 2.04, 1.3),
    0.045,
    chrome,
  );
  const handle = MeshBuilder.CreateTorus(
    "Kettle handle",
    { diameter: 0.43, thickness: 0.035, tessellation: 24 },
    scene,
  );
  handle.position.set(-6.7, 2.05, 1.3);
  handle.rotation.x = Math.PI / 2;
  handle.material = black;
  for (let i = 0; i < 3; i++)
    box("Biscuit jar", -6.7, 1.94, -1.4 + i * 0.4, 0.22, 0.38, 0.22, cupMat);
  box("Stove base", -7.0, 1.77, 2.4, 0.52, 0.1, 0.54, black);
  // Tattered cloth awning, newspaper stack and produce baskets.
  const awningMat = material(scene, "Tea awning striped fabric", "#b84a32");
  const awning = box(
    "Tea shop shade",
    -5.25,
    2.67,
    0,
    1.1,
    0.035,
    6.6,
    awningMat,
  );
  awning.rotation.z = 0.18;
  for (let z = -3.2; z < 3.2; z += 0.5)
    box("Awning pale stripes", -5.25, 2.7, z, 1.1, 0.02, 0.18, paper);
  for (let i = 0; i < 5; i++)
    box(
      "Newspaper stack",
      -6.7,
      1.77 + i * 0.012,
      -2.4,
      0.45,
      0.01,
      0.3,
      paper,
    );
  // Utility poles with insulators and many hanging cables crossing the lane.
  for (const z of [-14, 6, 22])
    for (const s of [-1, 1]) {
      const x = s * 5.8;
      post(
        "Concrete electric pole",
        new Vector3(x, 0, z),
        new Vector3(x, 9, z),
        0.11,
        cream,
      );
      box("Power crossbar", x, 8.2, z, 2, 0.09, 0.09, black);
      for (let k = -1; k <= 1; k++) {
        post(
          "Ceramic insulator",
          new Vector3(x + k * 0.65, 8.2, z),
          new Vector3(x + k * 0.65, 8.5, z),
          0.055,
          glass,
        );
        const next = z + 20;
        if (z < 22) {
          const path = Curve3.CreateQuadraticBezier(
            new Vector3(x + k * 0.2, 8.45, z),
            new Vector3(x + k * 0.2, 6.0, z + 10),
            new Vector3(x + k * 0.2, 8.45, next),
            25,
          ).getPoints();
          const cable = MeshBuilder.CreateTube(
            "Sagging utility cable",
            { path, radius: 0.014, tessellation: 5 },
            scene,
          );
          cable.material = black;
        }
      }
      const cross = Curve3.CreateQuadraticBezier(
        new Vector3(-5.8, 8.0, z),
        new Vector3(0, 5.7, z + 1),
        new Vector3(5.8, 8.4, z + 0.5),
        25,
      ).getPoints();
      for (let k = 0; k < 3; k++) {
        const cable = MeshBuilder.CreateTube(
          "Tangled wire crossing street",
          {
            path: cross.map((p) => p.add(new Vector3(0, k * 0.13, k * 0.12))),
            radius: 0.013,
            tessellation: 5,
          },
          scene,
        );
        cable.material = black;
      }
      const arm = post(
        "Street lamp arm",
        new Vector3(x, 6.9, z),
        new Vector3(x - s * 1.6, 6.8, z),
        0.035,
        black,
      );
      arm.receiveShadows = true;
      const lamp = box(
        "Street lamp housing",
        x - s * 1.6,
        6.76,
        z,
        0.5,
        0.12,
        0.23,
        cream,
      );
      lamps.push(lamp);
    }
  // Divider planters and yellow/black road barriers at the bend.
  for (let z = 13; z < 24; z += 2.3) {
    box("Divider concrete base", -0.2, 0.24, z, 0.46, 0.5, 1.9, yellow, true);
    box("Divider black band", -0.2, 0.25, z, 0.48, 0.24, 0.4, black);
  }
  // Fictional road meeting, bamboo frame, banner and microphones.
  const stage = box(
    "Temporary wooden meeting platform",
    1.8,
    0.23,
    10.6,
    4,
    0.45,
    3,
    wood,
    true,
  );
  obstacles.push({ x: 1.8, z: 10.6, w: 4, d: 3, h: 0.45 });
  for (const x of [0, 3.7])
    post(
      "Bamboo banner support",
      new Vector3(x, 0, 12),
      new Vector3(x, 4, 12),
      0.045,
      wood,
    );
  label(
    "রাস্তা বন্ধ, উন্নয়ন চলছে!",
    "কাল্পনিক প্রতিশ্রুতি পরিষদ",
    1.85,
    3.0,
    11.95,
    4.5,
    1.0,
    0,
    "#722f29",
  );
  box("Podium", 1.8, 0.95, 9.55, 0.75, 1.35, 0.5, wood, true);
  label("কথাই কাজ", "বজলু ভাই", 1.8, 1.16, 9.28, 0.67, 0.58, 0, "#22564b");
  post(
    "Microphone stand",
    new Vector3(1.8, 1.5, 9.55),
    new Vector3(1.8, 2.05, 9.55),
    0.018,
    black,
  );
  post(
    "Microphone",
    new Vector3(1.8, 2.05, 9.55),
    new Vector3(1.8, 2.05, 9.35),
    0.035,
    black,
  );
  for (const x of [-0.25, 4.0]) {
    box("PA speaker cabinet", x, 0.8, 10, 0.7, 1.2, 0.65, black, true);
    for (const y of [0.55, 1.04]) {
      const speaker = MeshBuilder.CreateCylinder(
        "Speaker cone",
        { diameter: 0.43, height: 0.03, tessellation: 24 },
        scene,
      );
      speaker.position.set(x, y, 9.66);
      speaker.rotation.x = Math.PI / 2;
      speaker.material = rubber;
    }
  }
  stage.receiveShadows = true;
  // Posters and cloth laundry: all text stays Bengali and fictional.
  for (const [x, z, a] of [
    [-7.96, 7.5, -Math.PI / 2],
    [7.96, -5, Math.PI / 2],
    [7.96, 13, Math.PI / 2],
  ]) {
    label(
      "প্রতিশ্রুতির শেষ নাই",
      "পথচারীর পথ চাই",
      x,
      1.7,
      z,
      1.3,
      1.7,
      a,
      "#e3cc91",
    );
  }
  for (let i = 0; i < 10; i++) {
    const x = 8.1,
      z = -14 + i * 0.47;
    box("Hanging local cloth", x, 5.9, z, 0.05, 0.9, 0.35, i % 2 ? teal : red);
  }
  // Small debris is textured paper and leaves, never large placeholder props.
  for (let i = 0; i < 36; i++) {
    const x = (random() > 0.5 ? 1 : -1) * (4.8 + random() * 0.4),
      z = -18 + random() * 42;
    const litter = box(
      "Street paper",
      x,
      0.03,
      z,
      0.12 + random() * 0.12,
      0.006,
      0.1,
      paper,
    );
    litter.rotation.y = random() * 6.3;
  }
  createRickshaw(scene, shadow, new Vector3(-4.1, 0, -3.7), -0.18);
  createCNG(scene, shadow, new Vector3(4.0, 0, 2.0), Math.PI);
  obstacles.push(
    { x: -4.1, z: -3.7, w: 1.6, d: 2.8, h: 2 },
    { x: 4, z: 2, w: 1.6, d: 2.9, h: 1.9 },
  );
  // A partially visible local bus at the far end gives scale, no real operator branding.
  box("Distant bus body", 3.0, 1.5, 24, 2.6, 2.7, 6.1, teal, true);
  box("Bus cream stripe", 3, 1.5, 24, 2.65, 0.36, 6.15, paper);
  for (let z = 22; z < 26.5; z += 0.8)
    box("Bus windows", 1.66, 2.22, z, 0.04, 0.8, 0.64, glass);
  label("নতুন সকাল পরিবহন", "ধীরে চলুন", 3, 2.2, 20.91, 2.3, 0.65, 0);
  for (const x of [1.65, 4.35])
    for (const z of [22.0, 25.9]) {
      const t = MeshBuilder.CreateCylinder(
        "Bus tire",
        { diameter: 1, height: 0.24, tessellation: 20 },
        scene,
      );
      t.rotation.z = Math.PI / 2;
      t.position.set(x, 0.48, z);
      t.material = rubber;
    }
  // Small potted palms beside the tea stall.
  for (const z of [-4.3, 4.5]) {
    const pot = MeshBuilder.CreateLathe(
      "Clay plant pot",
      {
        shape: [
          new Vector3(0.19, 0, 0),
          new Vector3(0.3, 0.47, 0),
          new Vector3(0.31, 0.52, 0),
        ],
        tessellation: 18,
        sideOrientation: Mesh.DOUBLESIDE,
      },
      scene,
    );
    pot.position.set(-6.4, 0.2, z);
    pot.material = red;
    const leafMat = material(scene, `Palm leaves ${z}`, "#465e32");
    for (let j = 0; j < 9; j++) {
      const a = (j / 9) * Math.PI * 2;
      const path = Curve3.CreateQuadraticBezier(
        new Vector3(-6.4, 0.6, z),
        new Vector3(-6.4 + Math.cos(a) * 0.5, 1.7, z + Math.sin(a) * 0.5),
        new Vector3(-6.4 + Math.cos(a) * 0.8, 1.2, z + Math.sin(a) * 0.8),
        8,
      ).getPoints();
      const leaf = MeshBuilder.CreateTube(
        "Palm frond",
        { path, radius: 0.035, tessellation: 5 },
        scene,
      );
      leaf.material = leafMat;
    }
  }
  scene.fogMode = Scene.FOGMODE_EXP2;
  scene.fogColor = hex("#b5c3bb");
  scene.fogDensity = 0.009;
  scene.clearColor = new Color4(0.63, 0.73, 0.74, 1);
  return { obstacles, lamps, buildings, shadow };
}

function vehicleHelpers(
  scene: Scene,
  shadow: ShadowGenerator,
  root: TransformNode,
) {
  const iron = material(
      scene,
      `${root.name} painted chassis`,
      "#24574e",
      0.6,
      0.45,
    ),
    tire = material(scene, `${root.name} rubber`, "#202421"),
    rim = material(scene, `${root.name} chrome`, "#b5bcb2", 0.3, 0.85);
  const b = (
    n: string,
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    m: PBRMaterial,
  ) => {
    const o = MeshBuilder.CreateBox(
      n,
      { width: w, height: h, depth: d },
      scene,
    );
    o.parent = root;
    o.position.set(x, y, z);
    o.material = m;
    o.receiveShadows = true;
    shadow.addShadowCaster(o);
    return o;
  };
  const tube = (
    n: string,
    points: number[][],
    r: number,
    m: PBRMaterial = iron,
  ) => {
    const o = MeshBuilder.CreateTube(
      n,
      {
        path: points.map((p) => Vector3.FromArray(p)),
        radius: r,
        tessellation: 8,
      },
      scene,
    );
    o.parent = root;
    o.material = m;
    return o;
  };
  const wheel = (x: number, z: number, r = 0.38) => {
    const w = MeshBuilder.CreateTorus(
      "Vehicle tire tread",
      { diameter: r * 2, thickness: 0.075, tessellation: 32 },
      scene,
    );
    w.parent = root;
    w.position.set(x, r, z);
    w.rotation.z = Math.PI / 2;
    w.material = tire;
    shadow.addShadowCaster(w);
    const hub = MeshBuilder.CreateCylinder(
      "Wheel hub",
      { diameter: 0.09, height: 0.15, tessellation: 12 },
      scene,
    );
    hub.parent = root;
    hub.position.copyFrom(w.position);
    hub.rotation.z = Math.PI / 2;
    hub.material = rim;
    for (let k = 0; k < 16; k++) {
      const a = (k / 16) * Math.PI * 2;
      tube(
        "Wheel spoke",
        [
          [x, r, z],
          [x, r + Math.cos(a) * (r - 0.05), z + Math.sin(a) * (r - 0.05)],
        ],
        0.008,
        rim,
      );
    }
    return w;
  };
  return { iron, tire, rim, b, tube, wheel };
}
export function createRickshaw(
  scene: Scene,
  shadow: ShadowGenerator,
  position: Vector3,
  angle: number,
) {
  const root = new TransformNode("Hand-painted Dhaka cycle rickshaw", scene);
  root.position = position;
  root.rotation.y = angle;
  const { iron, rim, b, tube, wheel } = vehicleHelpers(scene, shadow, root);
  const red = material(scene, "Rickshaw upholstered crimson", "#a32a36", 0.88),
    yellow = material(scene, "Rickshaw golden trim", "#e4b844", 0.5, 0.25),
    paint = material(scene, "Original floral rickshaw painting", "#ffffff");
  paint.albedoTexture = rickshawArt(scene);
  wheel(-0.62, -0.6);
  wheel(0.62, -0.6);
  wheel(0, 1.12, 0.41);
  tube(
    "Cycle frame",
    [
      [-0.55, 0.42, -0.6],
      [0, 0.5, 0.2],
      [0, 0.45, 1.12],
      [0, 1.02, 1.02],
      [0, 0.54, 0.25],
    ],
    0.037,
    iron,
  );
  tube(
    "Rear axle",
    [
      [-0.7, 0.38, -0.6],
      [0.7, 0.38, -0.6],
    ],
    0.045,
    iron,
  );
  tube(
    "Fork",
    [
      [0, 1.03, 0.98],
      [0, 0.42, 1.12],
    ],
    0.03,
    rim,
  );
  tube(
    "Handlebar",
    [
      [-0.35, 1.1, 1.05],
      [0, 1.16, 1.05],
      [0.35, 1.1, 1.05],
    ],
    0.027,
    rim,
  );
  b("Passenger seat", 0, 0.78, -0.55, 1.1, 0.17, 0.67, red);
  b("Painted rear panel", 0, 0.97, -0.95, 1.23, 0.94, 0.08, paint);
  b("Passenger footboard", 0, 0.42, 0.03, 1.1, 0.08, 0.56, yellow);
  b("Driver leather saddle", 0, 0.96, 0.58, 0.27, 0.08, 0.32, red);
  for (const s of [-1, 1]) {
    tube(
      "Ornate seat rail",
      [
        [s * 0.58, 0.5, 0.2],
        [s * 0.58, 1.04, -0.0],
        [s * 0.58, 1.14, -0.8],
        [s * 0.58, 0.5, -1],
      ],
      0.027,
      yellow,
    );
    tube(
      "Canopy support",
      [
        [s * 0.62, 0.6, -0.82],
        [s * 0.62, 1.65, -0.93],
        [s * 0.6, 1.91, -0.45],
        [s * 0.56, 1.68, 0.18],
      ],
      0.028,
      yellow,
    );
  }
  const paths = [];
  for (let z = -1.0; z <= 0.25; z += 0.08) {
    const path = [];
    for (let i = 0; i <= 16; i++) {
      const t = (i / 16) * Math.PI;
      path.push(new Vector3(Math.cos(t) * 0.67, 1.51 + Math.sin(t) * 0.46, z));
    }
    paths.push(path);
  }
  const hood = MeshBuilder.CreateRibbon(
    "Curved fabric rickshaw hood",
    { pathArray: paths, sideOrientation: Mesh.DOUBLESIDE },
    scene,
  );
  hood.parent = root;
  hood.material = paint;
  shadow.addShadowCaster(hood);
  tube(
    "Canopy gold front edge",
    paths[paths.length - 1].map((p) => [p.x, p.y, p.z]),
    0.026,
    yellow,
  );
  return root;
}
export function createCNG(
  scene: Scene,
  shadow: ShadowGenerator,
  position: Vector3,
  angle: number,
) {
  const root = new TransformNode("Green Dhaka CNG three wheeler", scene);
  root.position = position;
  root.rotation.y = angle;
  const { iron, tire, rim, b, tube, wheel } = vehicleHelpers(
    scene,
    shadow,
    root,
  );
  const green = material(scene, "CNG green enamel", "#237e4b", 0.35, 0.28),
    black = material(scene, "CNG black canvas roof", "#242c29", 0.91),
    glass = material(scene, "CNG windshield", "#6c9eaa", 0.12, 0.25),
    seat = material(scene, "CNG padded seat", "#633e2b");
  glass.alpha = 0.62;
  wheel(-0.6, -0.74, 0.29);
  wheel(0.6, -0.74, 0.29);
  wheel(0, 1.05, 0.29);
  b("CNG lower body", 0, 0.57, -0.06, 1.38, 0.45, 2.15, green);
  b("CNG rear body", 0, 0.96, -1.02, 1.38, 0.9, 0.16, green);
  b("CNG passenger bench", 0, 0.83, -0.66, 1.13, 0.2, 0.5, seat);
  b("CNG backrest", 0, 1.14, -0.9, 1.14, 0.5, 0.11, seat);
  b("CNG driver seat", 0, 0.88, 0.4, 0.45, 0.21, 0.46, black);
  const nose = MeshBuilder.CreateLathe(
    "CNG curved front cowling",
    {
      shape: [
        new Vector3(0.17, 0, 0),
        new Vector3(0.52, 0.13, 0),
        new Vector3(0.56, 0.4, 0),
        new Vector3(0.48, 0.5, 0),
      ],
      tessellation: 32,
    },
    scene,
  );
  nose.parent = root;
  nose.position.set(0, 0.47, 0.83);
  nose.scaling.z = 0.48;
  nose.material = green;
  shadow.addShadowCaster(nose);
  b("CNG windshield", 0, 1.36, 0.9, 1.04, 0.64, 0.035, glass);
  for (const x of [-0.6, 0.6]) {
    tube(
      "CNG roof pillar",
      [
        [x, 0.6, -1.08],
        [x, 1.7, -1.02],
        [x, 1.78, 0.52],
        [x * 0.78, 1.1, 1.03],
      ],
      0.031,
      iron,
    );
    tube(
      "CNG side protective rail",
      [
        [x, 0.67, -0.9],
        [x, 1.12, -0.88],
        [x, 1.12, 0.2],
      ],
      0.025,
      rim,
    );
  }
  // Arched black canvas roof with green seams.
  const pathArray = [];
  for (let z = -1.12; z < 0.82; z += 0.12) {
    const path = [];
    for (let i = 0; i <= 12; i++) {
      const x = -0.69 + (i / 12) * 1.38;
      path.push(new Vector3(x, 1.7 + 0.19 * Math.sin((i / 12) * Math.PI), z));
    }
    pathArray.push(path);
  }
  const roof = MeshBuilder.CreateRibbon(
    "CNG canvas roof",
    { pathArray, sideOrientation: Mesh.DOUBLESIDE },
    scene,
  );
  roof.parent = root;
  roof.material = black;
  shadow.addShadowCaster(roof);
  for (const x of [-0.4, 0.4]) {
    const lamp = MeshBuilder.CreateSphere(
      "CNG round headlamp",
      { diameter: 0.17, segments: 16 },
      scene,
    );
    lamp.parent = root;
    lamp.position.set(x, 0.81, 1.1);
    lamp.material = material(scene, `Headlight ${x}`, "#e7d7a7", 0.2, 0.25);
  }
  b("CNG bumper", 0, 0.4, 1.18, 1.15, 0.09, 0.1, rim);
  b(
    "CNG rear plate",
    0,
    0.59,
    -1.12,
    0.6,
    0.23,
    0.02,
    material(scene, "CNG number plate", "#eee4c8"),
  );
  const t = texture(scene, "Fictional Bengali vehicle plate", 256, 128, (c) => {
    c.fillStyle = "#ded9b9";
    c.fillRect(0, 0, 256, 128);
    c.textAlign = "center";
    c.fillStyle = "#19392d";
    c.font = "700 30px 'Noto Sans Bengali'";
    c.fillText("ঢাকা • কল্প", 128, 48);
    c.fillText("০১–২৩৪৫", 128, 94);
  });
  const plate = MeshBuilder.CreatePlane(
    "Bengali CNG plate",
    { width: 0.56, height: 0.22 },
    scene,
  );
  plate.parent = root;
  plate.position.set(0, 0.59, -1.135);
  const pm = new StandardMaterial("Plate typography", scene);
  pm.diffuseTexture = t;
  pm.specularColor = Color3.Black();
  plate.material = pm;
  b("CNG engine grille", 0, 0.72, -1.13, 0.8, 0.3, 0.02, tire);
  for (let k = 0; k < 6; k++)
    b("Grille slat", -0.34 + k * 0.13, 0.72, -1.15, 0.022, 0.27, 0.02, rim);
  return root;
}
export function disposeMeshes(meshes: AbstractMesh[]) {
  for (const m of meshes) m.dispose();
}
export type ArtTexture = DynamicTexture;
