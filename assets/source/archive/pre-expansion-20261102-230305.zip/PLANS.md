# Build plan

1. **Phase 00**: audit the intended directory and Git state; preserve any existing standalone game work; create or maintain the harness, language/content contract and gated phase specifications; consult current Context7 APIs and npm package metadata when reachable.
2. **Phase 01**: establish TypeScript/Vite/React/Babylon/Havok workspace; author original editable character/vehicle assets; build detailed street, controls, physical throws, Bengali UI and quality/audio presets.
3. **Evidence**: types/lint/domain tests/build; serve production locally; desktop and emulated mobile rendering and gameplay inspection; measured FPS and three camera screenshots. Record real limits honestly.
4. Stop at the Phase 01 gate. Failed visual or device criteria remain open, not silently approved.
