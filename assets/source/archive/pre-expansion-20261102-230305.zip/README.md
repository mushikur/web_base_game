# নেতা উঠছে!

**প্রতিশ্রুতি অনেক। রাস্তাটা ছাড়েন!**

Standalone Bengali third-person web game, set on one fictional Dhaka block around **কেটলি কেবিনেট**. Only Phase 00 and Phase 01 are in scope. This repository has no connection to any commerce project or database.

Current gate: [Phase 00–01 resumption review](harness/phase-01-review.md). Seven checks pass, but the latest mobile/visual regression is incomplete after the user stopped Computer Use. Phase 01 is not marked complete or approved.

The photo-led graphics revision adds detailed vehicle geometry, reference-inspired material maps, HDR lighting, desktop contact shading, street trees/railings/posters/drains and six blended character animations with local garments. Drag to orbit and use the mouse wheel to zoom. See [the graphics revision report](harness/graphics-upgrade.md).

## Run locally

Node >=22.12 is required (tested with Node 26.5.0).

```powershell
npm ci
npm run dev
```

For the tested production version:

```powershell
npm run build
npm run preview
```

Open [the local game](http://127.0.0.1:4173/). No account, API key, database, upload or external font service is needed.

## Controls

Walk with W/A/S/D or arrows, hold Shift to run, E to collect, 1/2 to select an item, Space to throw, drag the scene to orbit, Escape to pause. Mobile has a touch joystick, hold-to-run, collect and throw buttons. Nearby pickups supply six items and refill after fifteen active seconds. Throws follow Havok gravity with a modest forward aiming assist. Civilians award no points and cost player health if hit. Close worker crowds can push the player and reduce health. This is deliberately a single-area practice slice, without full mission completion or the later newspaper system.

## Architecture

- `apps/game`: React Bengali interface, Vite build, Babylon 9 3D scene, Havok Physics V2 projectiles, original animated GLB player/NPCs, spatial Web Audio.
- `packages/shared`: Bengali content, item rewards, quality settings, movement bounds and ballistic launch calculation.
- `apps/admin`, `apps/server`: reserved boundary documentation only; no later-phase implementation.
- `assets/source`: editable original GLB authoring; runtime GLB in `public/assets/models`.
- `harness/build`: gated phase specifications 00–06; `harness/context`: scope/API decisions; `harness/build-log.md`: observed results and limitations; `harness/evidence`: screenshots and recorded checks.

## Verification and evidence

```powershell
npm run verify
npm run assets
```

Append `?qa=1` to the URL to show a Bengali runtime diagnostics disclosure with actual frame samples, positions, skeleton and animation counts. It does not appear in the ordinary game. No analytics or remote telemetry is sent.

Read [build evidence](harness/build-log.md), [acceptance status](harness/phase-01-status.md) and [asset provenance](ASSETS.md) before treating the slice as approved. Mobile viewport emulation is not Android hardware qualification. Later phases require explicit approval.
