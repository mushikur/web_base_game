# Reserved — Phases 04–05

No API, database or multiplayer is started in Phase 01. Future Node/Colyseus server owns score and pickup authority. Context7 verified package families; recheck exact versions at that phase.
