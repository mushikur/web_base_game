import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import "@fontsource/noto-sans-bengali/400.css";
import "@fontsource/noto-sans-bengali/600.css";
import "@fontsource/noto-sans-bengali/700.css";
import "@fontsource/noto-sans-bengali/800.css";
import { bn, content, type Item } from "@neta/shared";
import type { DhakaGame, Snapshot } from "./game";
import "./style.css";

function Icon({ name, size = 22 }: { name: string; size?: number }) {
  const paths: Record<string, React.ReactNode> = {
    arrow: (
      <>
        <path d="M4 12h15M13 6l6 6-6 6" />
      </>
    ),
    pause: (
      <>
        <path d="M8 5v14M16 5v14" />
      </>
    ),
    sun: (
      <>
        <circle cx="12" cy="12" r="4" />
        <path d="M12 1v3m0 16v3M1 12h3m16 0h3M4 4l2 2m12 12 2 2M4 20l2-2M18 6l2-2" />
      </>
    ),
    sound: (
      <>
        <path d="M4 9v6h4l5 4V5L8 9H4Zm13-1q6 4 0 8m2-11q9 7 0 14" />
      </>
    ),
    settings: (
      <>
        <path d="m9 3-1 3-3 1-2 4 2 2v4l4 2 3-1 3 1 4-2v-4l2-2-2-4-3-1-1-3Z" />
        <circle cx="12" cy="11" r="3" />
      </>
    ),
    close: <path d="m6 6 12 12M6 18 18 6" />,
    pin: (
      <>
        <path d="M18 9c0 5-6 11-6 11S6 14 6 9a6 6 0 1 1 12 0Z" />
        <circle cx="12" cy="9" r="2" />
      </>
    ),
    egg: <path d="M19 14c0 5-14 5-14 0C5 8 9 3 12 3s7 5 7 11Z" />,
    sandal: (
      <>
        <path d="M8 3c3-2 8 0 8 4l2 12c-1 3-9 4-11 0L6 8c0-3 1-4 2-5Z" />
        <path d="m7 10 5-3 5 3m-5-3v5" />
      </>
    ),
    heart: (
      <path d="M20 5c-3-3-7 0-8 2-1-2-5-5-8-2-5 5 8 15 8 15S25 10 20 5Z" />
    ),
    target: (
      <>
        <circle cx="12" cy="12" r="8" />
        <circle cx="12" cy="12" r="3" />
        <path d="M12 1v4m0 14v4M1 12h4m14 0h4" />
      </>
    ),
    rickshaw: (
      <>
        <circle cx="5" cy="17" r="3" />
        <circle cx="20" cy="17" r="3" />
        <path d="m5 17 4-8 5 8H5m9 0 4-10h3M8 5h4M2 12V5c1-5 12-5 13 0v7m-13 0h11M4 6h8" />
      </>
    ),
    hand: (
      <>
        <path d="M7 13V7a1.5 1.5 0 0 1 3 0v4-7a1.5 1.5 0 0 1 3 0v7-5a1.5 1.5 0 0 1 3 0v6-3a1.5 1.5 0 0 1 3 0v7c0 7-10 8-13 3l-4-6c-1-2 2-3 3-1l2 2Z" />
      </>
    ),
  };
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name] ?? paths.target}
    </svg>
  );
}

function MiniMap({ s }: { s: Snapshot }) {
  const px = 75 + s.x * 5,
    pz = 142 - (s.z + 9) * 3.2;
  return (
    <aside className="minimap" aria-label="প্রতিশ্রুতি মোড়ের ছোট মানচিত্র">
      <div className="map-head">
        <Icon name="pin" size={15} />
        <span>প্রতিশ্রুতি মোড়</span>
        <span className="north">উ</span>
      </div>
      <svg
        viewBox="0 0 150 170"
        className="map-svg"
        role="img"
        aria-label="আপনি, চায়ের দোকান, ডিম, স্যান্ডেল এবং সভার অবস্থান"
      >
        <defs>
          <pattern
            id="map-grid"
            width="16"
            height="16"
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M16 0H0V16"
              fill="none"
              stroke="#e6d5ac"
              strokeWidth=".4"
            />
          </pattern>
        </defs>
        <rect width="150" height="170" fill="#d8d3b5" />
        <rect width="150" height="170" fill="url(#map-grid)" />
        <path d="M53 0h44v170H53Z" fill="#6b796a" />
        <path
          d="M74 0v170"
          stroke="#d7caa4"
          strokeWidth="1"
          strokeDasharray="4 6"
        />
        {[10, 48, 92, 132].map((z, i) => (
          <g key={z}>
            <rect
              x="9"
              y={z}
              width="35"
              height="28"
              rx="2"
              fill={i === 2 ? "#b77847" : "#b4b298"}
            />
            <rect x="107" y={z} width="35" height="28" rx="2" fill="#b4b298" />
          </g>
        ))}
        <text x="26" y="111" textAnchor="middle" fontSize="9" fill="#fef1d2">
          চা
        </text>
        <circle cx="83" cy="78" r="4" fill="#8c3f30" />
        <circle cx="67" cy="131" r="3" fill="#edc65a" />
        <circle cx="81" cy="124" r="3" fill="#edc65a" />
        <g
          transform={`translate(${Math.max(5, Math.min(145, px))} ${Math.max(5, Math.min(160, pz))}) rotate(${(s.yaw * 180) / Math.PI})`}
        >
          <path
            d="m0-7 5 12-5-2-5 2Z"
            fill="#fff7d8"
            stroke="#183e34"
            strokeWidth="1.8"
          />
        </g>
      </svg>
      <div className="map-legend">
        <i /> আপনি <i className="target-dot" /> সভা
      </div>
    </aside>
  );
}

function Joystick({ game }: { game: DhakaGame }) {
  const ref = useRef<HTMLDivElement>(null);
  const [point, setPoint] = useState({ x: 0, y: 0 });
  const update = (e: React.PointerEvent) => {
    const r = ref.current!.getBoundingClientRect(),
      x = (e.clientX - r.left - r.width / 2) / 38,
      y = (e.clientY - r.top - r.height / 2) / 38,
      l = Math.max(1, Math.hypot(x, y));
    setPoint({ x: (x / l) * 30, y: (y / l) * 30 });
    game.joystick(x / l, y / l);
  };
  const end = () => {
    setPoint({ x: 0, y: 0 });
    game.joystick(0, 0);
  };
  return (
    <div
      ref={ref}
      className="joystick"
      role="group"
      aria-label="চলার স্পর্শ নিয়ন্ত্রণ"
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        update(e);
      }}
      onPointerMove={(e) => {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) update(e);
      }}
      onPointerUp={end}
      onPointerCancel={end}
    >
      <div style={{ transform: `translate(${point.x}px,${point.y}px)` }} />
      <span>চলুন</span>
    </div>
  );
}

function App() {
  const canvas = useRef<HTMLCanvasElement>(null),
    game = useRef<DhakaGame | null>(null);
  const [s, setS] = useState<Snapshot | null>(null),
    [settings, setSettings] = useState(false),
    [help, setHelp] = useState(false),
    [startupError, setStartupError] = useState("");
  useEffect(() => {
    let g: DhakaGame | undefined;
    let cancelled = false;
    void import("./game")
      .then(({ DhakaGame }) => {
        if (cancelled) return;
        g = new DhakaGame(canvas.current!, setS);
        game.current = g;
        void g.init();
      })
      .catch((error: unknown) => {
        console.error(error);
        if (!cancelled)
          setStartupError(
            "এই ব্রাউজারে ত্রিমাত্রিক দৃশ্য চালু করা যায়নি। হালনাগাদ ব্রাউজারে আবার চেষ্টা করুন।",
          );
      });
    return () => {
      cancelled = true;
      g?.dispose();
    };
  }, []);
  const g = game.current;
  const openSettings = () => {
    setSettings(true);
    if (s?.playing && !s.paused) g?.pause();
  };
  const closeSettings = () => {
    setSettings(false);
    if (s?.playing && s.paused) g?.pause();
  };
  useEffect(() => {
    if (!settings && !help && !s?.paused) return;
    const prior = document.activeElement as HTMLElement | null;
    const handle = (event: KeyboardEvent) => {
      if (event.key === "Escape" && (settings || help)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        if (settings) {
          setSettings(false);
          if (game.current?.state.playing && game.current.state.paused)
            game.current.pause();
        }
        setHelp(false);
      }
      if (event.key === "Tab") {
        const dialog = document.querySelector<HTMLElement>('[role="dialog"]');
        const controls = Array.from(
          dialog?.querySelectorAll<HTMLElement>(
            'button,a[href],input,select,[tabindex="0"]',
          ) ?? [],
        ).filter((e) => e.offsetParent !== null);
        if (!controls.length) return;
        const first = controls[0],
          last = controls[controls.length - 1];
        if (
          event.shiftKey &&
          (document.activeElement === first ||
            !dialog?.contains(document.activeElement))
        ) {
          event.preventDefault();
          last.focus();
        } else if (
          !event.shiftKey &&
          (document.activeElement === last ||
            !dialog?.contains(document.activeElement))
        ) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    window.addEventListener("keydown", handle, true);
    return () => {
      window.removeEventListener("keydown", handle, true);
      if (prior?.isConnected) prior.focus();
    };
  }, [settings, help, s?.paused]);
  return (
    <main className={s?.playing ? "app is-playing" : "app"}>
      <canvas
        ref={canvas}
        className="game-canvas"
        tabIndex={0}
        aria-label="ঢাকার কাল্পনিক গলির ত্রিমাত্রিক খেলা"
      />
      <div className="scene-vignette" />
      {!s?.ready && (
        <div className="loading">
          <div className="loading-mark">
            <Icon name="rickshaw" size={52} />
          </div>
          <p>ঢাকার গলিতে স্বাগতম</p>
          <h1>{content.title}</h1>
          <span>
            {startupError ||
              s?.error ||
              "গলি সাজানো হচ্ছে… চায়ের কেটলিটা বসুক!"}
          </span>
          {s?.error || startupError ? (
            <button className="primary" onClick={() => location.reload()}>
              আবার চেষ্টা করুন
            </button>
          ) : (
            <div className="loading-line">
              <i />
            </div>
          )}
          <small>সব চরিত্র ও ঘটনা কাল্পনিক</small>
        </div>
      )}
      {s?.ready && !s.playing && (
        <>
          <header className="home-header">
            <a className="brand" href="#" aria-label="নেতা উঠছে! প্রচ্ছদ">
              <span className="brand-icon">
                <Icon name="rickshaw" size={28} />
              </span>
              <strong>
                নেতা উঠছে<span>!</span>
              </strong>
            </a>
            <nav>
              <span className="edition">
                <i /> ঢাকার গল্প, আপনার খেলা
              </span>
              <button
                className="icon-button"
                aria-label="সেটিংস খুলুন"
                onClick={openSettings}
              >
                <Icon name="settings" />
              </button>
            </nav>
          </header>
          <section className="home-copy">
            <div className="eyebrow">
              <span /> স্বাগতম, প্রতিশ্রুতি মোড়ে
            </div>
            <h1>
              নেতা
              <br />
              <span>উঠছে!</span>
              <svg viewBox="0 0 300 25" aria-hidden="true">
                <path
                  d="M8 15Q130-3 285 10M40 24Q190 6 272 20"
                  stroke="currentColor"
                  strokeWidth="5"
                  fill="none"
                />
              </svg>
            </h1>
            <h2>{content.slogan}</h2>
            <p>
              চায়ের কাপে ঝড়, রাস্তায় সভা।
              <br />
              এই গলির জট খুলবেন আপনিই!
            </p>
            <button className="primary play-button" onClick={() => g?.start()}>
              <span>গলিতে নামুন</span>
              <Icon name="arrow" size={25} />
            </button>
            <button className="text-button" onClick={() => setHelp(true)}>
              <span className="help-circle">?</span> কীভাবে খেলবেন
            </button>
            <div className="home-meta">
              <span>
                <Icon name="pin" size={15} /> এক টুকরো কাল্পনিক ঢাকা
              </span>
              <span>একক খেলা</span>
            </div>
          </section>
          <aside className="street-caption">
            <span className="caption-line" />
            <div>
              <small>আজকের ঠিকানা</small>
              <h3>কেটলি কেবিনেট</h3>
              <p>গরম চা, ঠান্ডা প্রতিশ্রুতি।</p>
            </div>
            <span className="area-number">০১</span>
          </aside>
          <footer className="home-footer">
            <span>হাসির খেলা। সব চরিত্র ও সংগঠন কাল্পনিক।</span>
            <span>
              তৈরি বাংলায়, ঢাকার মেজাজে <i>✦</i>
            </span>
          </footer>
        </>
      )}
      {s?.playing && g && (
        <>
          <header className="hud-header">
            <div className="player-card">
              <div className="avatar-monogram">স</div>
              <div>
                <strong>সজল পথিক</strong>
                <div className="health-line">
                  <Icon name="heart" size={13} />
                  <div className="health-track">
                    <i style={{ width: `${s.health}%` }} />
                  </div>
                  <span>{bn(s.health)}</span>
                </div>
              </div>
              <div className="score">
                <span>পয়েন্ট</span>
                <b>{bn(s.score).padStart(2, "০")}</b>
              </div>
            </div>
            <div className="location-pill">
              <i />
              {content.location}
              <span>{s.evening ? "বিকেলের আলো" : "দিনের আলো"}</span>
            </div>
            <div className="hud-tools">
              <button
                className="icon-button"
                aria-label={s.muted ? "শব্দ চালু করুন" : "শব্দ বন্ধ করুন"}
                onClick={() => g.mute()}
              >
                <Icon name="sound" />
                {s.muted && <i className="muted-slash" />}
              </button>
              <button
                className="icon-button"
                aria-label="বিরতি"
                onClick={() => g.pause()}
              >
                <Icon name="pause" />
              </button>
              <button
                className="icon-button"
                aria-label="সেটিংস খুলুন"
                onClick={openSettings}
              >
                <Icon name="settings" />
              </button>
            </div>
          </header>
          <section className="mission">
            <div className="mission-label">
              <span>এই গলির কাজ</span>
              <Icon name="target" size={17} />
            </div>
            <h2>সভা শেষ, রাস্তা খোলা!</h2>
            <p>{content.mission}</p>
            <div>
              <span className="step-number">১</span>
              <span>
                {s.egg + s.sandal > 0
                  ? "সামনে এগিয়ে সভার দিকে লক্ষ্য করুন"
                  : "কাছের ডিম ও স্যান্ডেল কুড়িয়ে নিন"}
              </span>
            </div>
          </section>
          <div className="crosshair" aria-hidden="true">
            <i />
            <i />
            <i />
            <i />
          </div>
          {s.target && (
            <aside className="target-status">
              <span>{s.target}</span>
              <div>
                <i style={{ width: `${s.targetHealth}%` }} />
              </div>
              <small>
                {s.targetHealth <= 0
                  ? "আজকের মতো ক্ষান্ত!"
                  : `ধৈর্য ${bn(s.targetHealth)}`}
              </small>
            </aside>
          )}
          <MiniMap s={s} />
          <div className="game-notice" role="status">
            {s.message}
          </div>
          {s.subtitle && (
            <div className="subtitle" aria-live="polite">
              {s.subtitle}
            </div>
          )}
          <div className="inventory" aria-label="সঙ্গে থাকা জিনিস">
            {(["egg", "sandal"] as Item[]).map((kind, i) => (
              <button
                key={kind}
                className={`item-slot ${s.selected === kind ? "selected" : ""}`}
                onClick={() => g.select(kind)}
                aria-label={`${content.items[kind]} বাছুন, ${bn(s[kind])}টি`}
                aria-pressed={s.selected === kind}
              >
                <span className="key-hint">{i + 1}</span>
                <Icon name={kind} size={30} />
                <span className="item-name">{content.items[kind]}</span>
                <b>× {bn(s[kind])}</b>
              </button>
            ))}
          </div>
          <div className="desktop-controls">
            <span>
              <kbd>W A S D</kbd> চলুন
            </span>
            <span>
              <kbd>Shift</kbd> দৌড়
            </span>
            <span>
              <kbd>E</kbd> কুড়ান
            </span>
            <span>
              <kbd>Space</kbd> ছুড়ুন
            </span>
            <span>টেনে ঘোরান • চাকা ঘুরিয়ে দেখুন</span>
          </div>
          <div className="action-buttons">
            <button
              className={`pickup-button ${s.nearPickup ? "near" : ""}`}
              onClick={() => g.pickup()}
              aria-label="কাছের জিনিস কুড়ান"
            >
              <Icon name="hand" />
              <span>কুড়ান</span>
            </button>
            <button className="throw-button" onClick={() => g.throw()}>
              <Icon name="target" size={29} />
              <span>ছুড়ুন</span>
            </button>
          </div>
          <div className="camera-tools" role="group" aria-label="ক্যামেরার দূরত্ব">
            <button aria-label="ক্যামেরা কাছে আনুন" onClick={() => g.zoom(-0.6)}>
              <span aria-hidden="true">＋</span> কাছে
            </button>
            <button aria-label="ক্যামেরা দূরে নিন" onClick={() => g.zoom(0.6)}>
              <span aria-hidden="true">−</span> দূরে
            </button>
          </div>
          <div className="mobile-controls">
            <Joystick game={g} />
            <button
              className="run-button"
              aria-label="দৌড়াতে ধরে রাখুন"
              onPointerDown={(e) => {
                e.currentTarget.setPointerCapture(e.pointerId);
                g.run(true);
              }}
              onPointerUp={() => g.run(false)}
              onPointerCancel={() => g.run(false)}
            >
              দৌড়
            </button>
          </div>
          {s.paused && !settings && (
            <div className="modal-backdrop">
              <section
                className="dialog pause-dialog"
                role="dialog"
                aria-modal="true"
                aria-labelledby="pause-title"
              >
                <span className="eyebrow">এক কাপ চায়ের বিরতি</span>
                <h2 id="pause-title">গলি অপেক্ষায় আছে।</h2>
                <p>
                  পয়েন্ট {bn(s.score)} • ছুড়েছেন {bn(s.throws)} বার
                </p>
                <button autoFocus className="primary" onClick={() => g.pause()}>
                  {s.health === 0 ? "আবার শুরু করুন" : "খেলায় ফিরুন"}{" "}
                  <Icon name="arrow" />
                </button>
                <button className="secondary" onClick={openSettings}>
                  সেটিংস
                </button>
                <button className="text-button" onClick={() => g.home()}>
                  প্রচ্ছদে ফিরুন
                </button>
              </section>
            </div>
          )}
        </>
      )}
      {settings && s && g && (
        <div className="modal-backdrop">
          <section
            className="dialog settings-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="settings-title"
          >
            <button
              className="dialog-close icon-button"
              aria-label="সেটিংস বন্ধ করুন"
              onClick={closeSettings}
            >
              <Icon name="close" />
            </button>
            <span className="eyebrow">আপনার মতো করে</span>
            <h2 id="settings-title">খেলার সেটিংস</h2>
            <fieldset>
              <legend>দৃশ্যের মান</legend>
              <div className="segmented">
                <button
                  className={s.quality === "desktop" ? "active" : ""}
                  aria-pressed={s.quality === "desktop"}
                  onClick={() => g.setQuality("desktop")}
                >
                  কম্পিউটার<span>বিস্তারিত ছায়া ও আলো</span>
                </button>
                <button
                  className={s.quality === "mobile" ? "active" : ""}
                  aria-pressed={s.quality === "mobile"}
                  onClick={() => g.setQuality("mobile")}
                >
                  মোবাইল<span>হালকা দৃশ্য, সহজে চলুক</span>
                </button>
              </div>
            </fieldset>
            <fieldset>
              <legend>গলির সময়</legend>
              <div className="segmented">
                <button
                  className={!s.evening ? "active" : ""}
                  aria-pressed={!s.evening}
                  onClick={() => g.setEvening(false)}
                >
                  দিনের আলো
                </button>
                <button
                  className={s.evening ? "active" : ""}
                  aria-pressed={s.evening}
                  onClick={() => g.setEvening(true)}
                >
                  বিকেলের আলো
                </button>
              </div>
            </fieldset>
            <div className="setting-row">
              <div>
                <strong>রাস্তার শব্দ</strong>
                <small>ইঞ্জিন, হর্ন আর শহরের গুঞ্জন</small>
              </div>
              <button
                className={`toggle ${!s.muted ? "on" : ""}`}
                role="switch"
                aria-checked={!s.muted}
                aria-label="রাস্তার শব্দ"
                onClick={() => g.mute()}
              >
                <i />
              </button>
            </div>
            <p className="language-note">
              ভাষা: বাংলা
              <br />
              <span>বাংলা লেখা, সংলাপ ও নির্দেশনাসহ।</span>
            </p>
            <button className="primary" autoFocus onClick={closeSettings}>
              ঠিক আছে <Icon name="arrow" />
            </button>
          </section>
        </div>
      )}
      {help && (
        <div className="modal-backdrop">
          <section
            className="dialog help-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="help-title"
          >
            <button
              className="dialog-close icon-button"
              aria-label="নির্দেশনা বন্ধ করুন"
              onClick={() => setHelp(false)}
            >
              <Icon name="close" />
            </button>
            <span className="eyebrow">গলির নিয়মকানুন</span>
            <h2 id="help-title">চলুন, রাস্তা খুলি।</h2>
            <ol>
              <li>ডিম আর স্যান্ডেলের কাছে গিয়ে কুড়িয়ে নিন।</li>
              <li>সভায় থাকা কাল্পনিক নেতাকর্মীদের দিকে লক্ষ্য করুন।</li>
              <li>ছুড়ুন, পয়েন্ট পান। পথচারীকে লাগলে পয়েন্ট নেই।</li>
            </ol>
            <p>
              কম্পিউটারে <kbd>W A S D</kbd> বা তীরচিহ্নে চলুন, <kbd>Shift</kbd>{" "}
              ধরে দৌড়ান। <kbd>E</kbd> দিয়ে কুড়ান, <kbd>Space</kbd> দিয়ে ছুড়ুন।
              দৃশ্য টেনে ক্যামেরা ঘোরান। মাউসের চাকা ঘুরিয়ে কাছে বা দূরে দেখুন।
            </p>
            <p>
              মোবাইলে বাঁয়ের গোল নিয়ন্ত্রণে চলুন, ডানের বোতামে কুড়ান ও ছুড়ুন।
              কাছে ও দূরে বোতাম দিয়ে ক্যামেরার দূরত্ব বদলান।
            </p>
            <button
              className="primary"
              autoFocus
              onClick={() => setHelp(false)}
            >
              বুঝেছি <Icon name="arrow" />
            </button>
          </section>
        </div>
      )}
      {new URLSearchParams(location.search).has("qa") && s?.ready && g && (
        <details className="qa-panel">
          <summary>পরীক্ষা • {bn(s.fps)} ফ্রেম/সে.</summary>
          <button onClick={() => g.resetBenchmark()}>নতুন মাপ নিন</button>
          <output
            data-testid="runtime-evidence"
            data-evidence={JSON.stringify(g.diagnostics())}
          >
            <p>গড় {bn(g.diagnostics().fpsAverage)} ফ্রেম/সে.</p>
            <p>
              স্থান {s.x.toFixed(2)}, {s.z.toFixed(2)}
            </p>
            <p>
              কঙ্কাল {bn(g.diagnostics().skeletons)} • অ্যানিমেশন{" "}
              {bn(g.diagnostics().animationGroups)}
            </p>
            <p>{content.shapingSample}</p>
          </output>
        </details>
      )}
    </main>
  );
}
createRoot(document.getElementById("root")!).render(<App />);
