/** Original synthesised traffic bed. Starts only after a player gesture. No sampled voices. */
export class StreetAudio {
  private context?: AudioContext;
  private master?: GainNode;
  private nodes: AudioNode[] = [];
  private timer?: number;
  async start() {
    if (this.context) {
      await this.context.resume();
      return;
    }
    const c = (this.context = new AudioContext());
    const gain = (this.master = c.createGain());
    gain.gain.value = 0.1;
    gain.connect(c.destination);
    const buffer = c.createBuffer(1, c.sampleRate * 3, c.sampleRate);
    const data = buffer.getChannelData(0);
    let smooth = 0;
    for (let i = 0; i < data.length; i++) {
      smooth = (smooth + (Math.random() * 2 - 1) * 0.035) * 0.99;
      data[i] = smooth;
    }
    const noise = c.createBufferSource();
    noise.buffer = buffer;
    noise.loop = true;
    const filter = c.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 420;
    noise.connect(filter);
    filter.connect(gain);
    noise.start();
    this.nodes.push(noise, filter);
    for (const [f, x, z] of [
      [52, -4, -4],
      [79, 4, 2],
      [104, 3, 24],
    ]) {
      const motor = c.createOscillator(),
        g = c.createGain(),
        pan = c.createPanner();
      motor.type = "triangle";
      motor.frequency.value = f;
      g.gain.value = 0.045;
      pan.panningModel = "HRTF";
      pan.distanceModel = "inverse";
      pan.refDistance = 4;
      pan.rolloffFactor = 1.2;
      pan.positionX.value = x;
      pan.positionY.value = 0.8;
      pan.positionZ.value = z;
      motor.connect(g);
      g.connect(pan);
      pan.connect(gain);
      motor.start();
      this.nodes.push(motor, g, pan);
    }
    this.timer = window.setInterval(() => {
      if (this.context?.state !== "running") return;
      this.horn(Math.random() > 0.5 ? -0.8 : 0.8);
    }, 6500);
    await c.resume();
  }
  private horn(panValue: number) {
    const c = this.context,
      gain = this.master;
    if (!c || !gain) return;
    const pan = c.createStereoPanner();
    pan.pan.value = panValue;
    pan.connect(gain);
    const g = c.createGain();
    g.gain.setValueAtTime(0, c.currentTime);
    g.gain.linearRampToValueAtTime(0.12, c.currentTime + 0.06);
    g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 0.6);
    g.connect(pan);
    for (const f of [310, 388]) {
      const o = c.createOscillator();
      o.frequency.value = f;
      o.type = "triangle";
      o.connect(g);
      o.start();
      o.stop(c.currentTime + 0.65);
    }
    window.setTimeout(() => {
      g.disconnect();
      pan.disconnect();
    }, 900);
  }
  effect(hit = false) {
    const c = this.context,
      g = this.master;
    if (!c || !g) return;
    const o = c.createOscillator(),
      v = c.createGain();
    o.frequency.setValueAtTime(hit ? 260 : 650, c.currentTime);
    o.frequency.exponentialRampToValueAtTime(
      hit ? 90 : 1150,
      c.currentTime + 0.13,
    );
    v.gain.setValueAtTime(0.25, c.currentTime);
    v.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 0.18);
    o.connect(v);
    v.connect(g);
    o.start();
    o.stop(c.currentTime + 0.19);
  }
  setMuted(muted: boolean) {
    if (this.master)
      this.master.gain.setTargetAtTime(
        muted ? 0 : 0.1,
        this.context!.currentTime,
        0.1,
      );
  }
  listener(x: number, z: number, yaw: number) {
    const c = this.context;
    if (!c) return;
    const l = c.listener,
      t = c.currentTime;
    l.positionX.setTargetAtTime(x, t, 0.08);
    l.positionY.setTargetAtTime(1.6, t, 0.08);
    l.positionZ.setTargetAtTime(z, t, 0.08);
    l.forwardX.setTargetAtTime(Math.sin(yaw), t, 0.08);
    l.forwardY.setTargetAtTime(0, t, 0.08);
    l.forwardZ.setTargetAtTime(Math.cos(yaw), t, 0.08);
    l.upY.value = 1;
  }
  get status() {
    return this.context?.state ?? "not-started";
  }
  pause(paused: boolean) {
    if (paused) void this.context?.suspend();
    else void this.context?.resume();
  }
  dispose() {
    if (this.timer) clearInterval(this.timer);
    this.nodes.forEach((n) => n.disconnect());
    void this.context?.close();
  }
}
