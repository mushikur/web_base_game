import {
  AnimationGroup,
  AbstractMesh,
  AssetContainer,
  Color4,
  HDRCubeTexture,
  DefaultRenderingPipeline,
  SSAO2RenderingPipeline,
  DirectionalLight,
  Engine,
  FreeCamera,
  HavokPlugin,
  HemisphericLight,
  LoadAssetContainerAsync,
  Mesh,
  MeshBuilder,
  ParticleSystem,
  PBRMaterial,
  PhysicsAggregate,
  PhysicsShapeType,
  Ray,
  Scene,
  ShadowGenerator,
  TransformNode,
  Vector3,
  VertexBuffer,
} from "./engine";
import "@babylonjs/loaders/glTF";
import HavokPhysics from "@babylonjs/havok";
import havokUrl from "@babylonjs/havok/lib/esm/HavokPhysics.wasm?url";
import {
  bn,
  canWalk,
  content,
  launchVelocity,
  qualitySettings,
  rewardForHit,
  type Item,
  type Quality,
  type Role,
} from "@neta/shared";
import { createWorld, type World } from "./world";
import { hex, material, texture } from "./art";
import { StreetAudio } from "./audio";
import { dressCharacter } from "./characterStyle";
import { FrameWindow } from "./frameStats";

export type Snapshot = {
  ready: boolean;
  playing: boolean;
  paused: boolean;
  score: number;
  health: number;
  egg: number;
  sandal: number;
  selected: Item;
  message: string;
  subtitle: string;
  target: string;
  targetHealth: number;
  fps: number;
  x: number;
  z: number;
  yaw: number;
  nearPickup: boolean;
  throws: number;
  hits: number;
  civilianHits: number;
  quality: Quality;
  evening: boolean;
  muted: boolean;
  error: string;
};
const initial: Snapshot = {
  ready: false,
  playing: false,
  paused: false,
  score: 0,
  health: 100,
  egg: 0,
  sandal: 0,
  selected: "egg",
  message: "ডিম আর স্যান্ডেল কুড়িয়ে রাস্তা খুলুন",
  subtitle: "",
  target: "",
  targetHealth: 100,
  fps: 0,
  x: 0,
  z: -9,
  yaw: 0,
  nearPickup: false,
  throws: 0,
  hits: 0,
  civilianHits: 0,
  quality: "desktop",
  evening: false,
  muted: false,
  error: "",
};
type Actor = {
  root: TransformNode;
  groups: AnimationGroup[];
  role: Role;
  name: string;
  health: number;
  base: Vector3;
  phase: number;
  anim: string;
  throwTime: number;
  hitTime: number;
  detail: AbstractMesh[];
  action: "Throw" | "Pickup";
};
type Pickup = {
  root: TransformNode;
  kind: Item;
  origin: Vector3;
  available: boolean;
  cooldown: number;
};
type Projectile = {
  mesh: Mesh;
  body: PhysicsAggregate;
  age: number;
  kind: Item;
  hit: boolean;
};
export class DhakaGame {
  readonly engine: Engine;
  readonly scene: Scene;
  readonly camera: FreeCamera;
  readonly audio = new StreetAudio();
  state = { ...initial };
  world!: World;
  player!: Actor;
  actors: Actor[] = [];
  pickups: Pickup[] = [];
  projectiles: Projectile[] = [];
  colliders: Mesh[] = [];
  private container?: AssetContainer;
  private shadow: ShadowGenerator;
  private sun: DirectionalLight;
  private hemi: HemisphericLight;
  private pipeline: DefaultRenderingPipeline;
  private ambientOcclusion?: SSAO2RenderingPipeline;
  private keys = new Set<string>();
  private time = 0;
  private uiTime = 0;
  private yaw = 0;
  private pitch = 0.18;
  private cameraDistance = 4.8;
  private pointer?: { id: number; x: number; y: number };
  private touch = { x: 0, y: 0 };
  private running = false;
  private disposed = false;
  private onChange: (s: Snapshot) => void;
  private messageUntil = 0;
  private subtitleUntil = 0;
  private targetUntil = 0;
  private healthTime = 0;
  private simulationActive = false;
  private cleanup: (() => void)[] = [];
  private frameWindow = new FrameWindow();
  private playerMotionsSeen = new Set<string>();
  constructor(
    readonly canvas: HTMLCanvasElement,
    onChange: (s: Snapshot) => void,
  ) {
    this.onChange = onChange;
    this.engine = new Engine(canvas, true, {
      preserveDrawingBuffer: true,
      stencil: true,
      adaptToDeviceRatio: false,
      powerPreference: "high-performance",
    });
    this.scene = new Scene(this.engine);
    this.scene.skipPointerMovePicking = true;
    this.scene.skipPointerDownPicking = true;
    this.scene.skipPointerUpPicking = true;
    this.scene.collisionsEnabled = true;
    this.camera = new FreeCamera(
      "Third person follow camera",
      new Vector3(1.8, 3, -14),
      this.scene,
    );
    this.camera.minZ = 0.12;
    this.camera.maxZ = 120;
    this.camera.fov = 0.9;
    this.camera.setTarget(new Vector3(0, 1.2, 0));
    this.scene.activeCamera = this.camera;
    this.sun = new DirectionalLight(
      "Humid Dhaka sunlight",
      new Vector3(0.65, -1, 0.5),
      this.scene,
    );
    this.sun.position.set(-25, 40, -20);
    this.sun.intensity = 2.0;
    this.sun.diffuse = hex("#ffe0ad");
    this.sun.shadowMinZ = 1;
    this.sun.shadowMaxZ = 95;
    this.sun.orthoLeft = -30;
    this.sun.orthoRight = 30;
    this.sun.orthoTop = 30;
    this.sun.orthoBottom = -30;
    this.sun.autoUpdateExtends = false;
    this.hemi = new HemisphericLight(
      "Sky bounce",
      new Vector3(0, 1, 0),
      this.scene,
    );
    this.hemi.intensity = 0.32;
    this.hemi.groundColor = hex("#525142");
    this.shadow = new ShadowGenerator(2048, this.sun);
    this.shadow.usePercentageCloserFiltering = true;
    this.shadow.filteringQuality = ShadowGenerator.QUALITY_LOW;
    this.shadow.bias = 0.0006;
    this.shadow.normalBias = 0.025;
    this.pipeline = new DefaultRenderingPipeline(
      "Restrained film tone",
      true,
      this.scene,
      [this.camera],
    );
    this.pipeline.fxaaEnabled = true;
    this.pipeline.bloomEnabled = true;
    this.pipeline.bloomThreshold = 1.5;
    this.pipeline.bloomWeight = 0.1;
    this.pipeline.bloomKernel = 32;
    this.pipeline.samples = 1;
    this.scene.imageProcessingConfiguration.toneMappingEnabled = true;
    this.scene.imageProcessingConfiguration.toneMappingType = 1;
    this.scene.imageProcessingConfiguration.exposure = 1.03;
    this.scene.imageProcessingConfiguration.contrast = 1.12;
    this.listen();
    this.engine.runRenderLoop(() => this.frame());
  }
  async init() {
    try {
      await document.fonts.load('700 48px "Noto Sans Bengali"');
      await document.fonts.ready;
      const havok = await HavokPhysics({ locateFile: () => havokUrl });
      if (this.disposed) return;
      this.scene.enablePhysics(
        new Vector3(0, -9.81, 0),
        new HavokPlugin(true, havok),
      );
      this.world = createWorld(this.scene, this.shadow);
      await this.environment();
      this.mergeArchitecture();
      this.physics();
      this.container = await LoadAssetContainerAsync(
        "/assets/models/dhaka-character.glb",
        this.scene,
      );
      if (this.disposed) return;
      this.player = this.actor(
        "সজল পথিক",
        "civilian",
        new Vector3(0, 0, -9),
        "#ac5933",
      );
      this.actors.push(
        this.actor(
          content.leader,
          "leader",
          new Vector3(1.8, 0.46, 10.6),
          "#e5d9ae",
        ),
      );
      [
        new Vector3(-1.8, 0, 7.8),
        new Vector3(3.3, 0, 7.4),
        new Vector3(0.1, 0, 6.6),
      ].forEach((p, i) =>
        this.actors.push(
          this.actor(
            content.workers[i],
            "worker",
            p,
            i === 1 ? "#6f433a" : "#47776d",
          ),
        ),
      );
      [
        new Vector3(-6.1, 0.2, -7),
        new Vector3(6.3, 0.2, 5.8),
        new Vector3(-6.1, 0.2, 8),
        new Vector3(6.4, 0.2, -10),
        new Vector3(-8.4, 0.33, 0.6),
      ].forEach((p, i) =>
        this.actors.push(
          this.actor(
            content.civilians[i],
            "civilian",
            p,
            ["#c9a471", "#c57568", "#a3b4a4", "#6491a0", "#cdbfa0"][i],
          ),
        ),
      );
      this.addPickup("egg", new Vector3(-1.4, 0.15, -5.7));
      this.addPickup("sandal", new Vector3(1.25, 0.15, -3.4));
      this.dust();
      this.setQuality(innerWidth < 760 ? "mobile" : "desktop");
      this.state.ready = true;
      this.emit();
    } catch (e) {
      console.error(e);
      this.state.error = "গলিটা খুলতে সমস্যা হয়েছে। আবার চেষ্টা করুন।";
      this.emit();
    }
  }
  private async environment() {
    await new Promise<void>((resolve, reject) => {
      const env = new HDRCubeTexture(
        "/assets/environment/dhaka-daylight-sky-1k.hdr",
        this.scene,
        128,
        false,
        true,
        false,
        true,
        () => resolve(),
        (message) => reject(new Error(message ?? "HDR lighting load failed")),
      );
      env.name = "Locally bundled CC0 daylight HDR probe";
      env.rotationY = 0.9;
      this.scene.environmentTexture = env;
      this.scene.environmentIntensity = 0.65;
      const sky = this.scene.createDefaultSkybox(env, true, 200, 0, false);
      if (sky) {
        sky.name = "Dhaka daylight atmosphere";
        sky.isPickable = false;
        sky.metadata = { staticBatchExclude: true };
      }
    });
  }
  private mergeArchitecture() {
    const map = new Map<PBRMaterial, Mesh[]>();
    const originalCasters = new Set(this.shadow.getShadowMap()?.renderList ?? []);
    const excluded = new Set(this.world.lamps);
    for (const m of [...this.scene.meshes]) {
      if (
        !(m instanceof Mesh) ||
        !m.material ||
        !(m.material instanceof PBRMaterial) ||
        m.getTotalVertices() === 0 ||
        excluded.has(m) ||
        m.metadata?.staticBatchExclude
      )
        continue;
      m.computeWorldMatrix(true);
      const list = map.get(m.material) ?? [];
      list.push(m);
      map.set(m.material, list);
    }
    for (const [mat, list] of map) {
      if (list.length < 2) continue;
      const merged = Mesh.MergeMeshes(
        list,
        true,
        true,
        undefined,
        false,
        false,
      );
      if (merged) {
        merged.name = `Detailed street — ${mat.name}`;
        merged.receiveShadows = true;
        merged.freezeWorldMatrix();
        if (list.some((mesh) => originalCasters.has(mesh)))
          this.shadow.addShadowCaster(merged);
      }
    }
  }
  private physics() {
    const ground = MeshBuilder.CreateBox(
      "Hidden physics ground",
      { width: 50, height: 0.3, depth: 72 },
      this.scene,
    );
    ground.position.y = -0.19;
    ground.visibility = 0;
    ground.isPickable = false;
    new PhysicsAggregate(
      ground,
      PhysicsShapeType.BOX,
      { mass: 0, restitution: 0.12 },
      this.scene,
    );
    for (const o of this.world.obstacles) {
      const h = o.h ?? 9;
      const m = MeshBuilder.CreateBox(
        "Hidden simple architecture collider",
        { width: o.w, height: h, depth: o.d },
        this.scene,
      );
      m.position.set(o.x, h / 2, o.z);
      m.visibility = 0;
      m.isPickable = false;
      m.checkCollisions = true;
      new PhysicsAggregate(
        m,
        PhysicsShapeType.BOX,
        { mass: 0, restitution: 0.15 },
        this.scene,
      );
      this.colliders.push(m);
    }
    for (const [name, x, y, z, w, h, d] of [
      ["Tea roof", -8.7, 3.56, 0, 6.6, 0.18, 8],
      ["Tea awning", -5.25, 2.7, 0, 1.1, 0.2, 6.6],
      ["Tea sign", -5.38, 3.15, 0, 0.16, 1.05, 6.85],
    ] as const) {
      const mesh = MeshBuilder.CreateBox(
        `Hidden camera collider ${name}`,
        { width: w, height: h, depth: d },
        this.scene,
      );
      mesh.position.set(x, y, z);
      mesh.visibility = 0;
      mesh.isPickable = false;
      this.colliders.push(mesh);
    }
  }
  private actor(name: string, role: Role, pos: Vector3, color: string): Actor {
    const instance = this.container!.instantiateModelsToScene(
      (n) => `${name}/${n}`,
      false,
      { doNotInstantiate: true },
    );
    const root = new TransformNode(name, this.scene);
    instance.rootNodes.forEach((n) => (n.parent = root));
    root.position.copyFrom(pos);
    const detail = dressCharacter(
      this.scene,
      root,
      this.shadow,
      name,
      role,
      color,
    );
    const groups = instance.animationGroups;
    for (const g of groups) {
      g.enableBlending = true;
      g.blendingSpeed = 0.1;
      g.speedRatio = g.name.endsWith("Walk")
        ? 1.6
        : g.name.endsWith("Run")
          ? 1.3
          : 1;
      if (g.name.endsWith("Idle")) {
        g.start(true);
        g.setWeightForAllAnimatables(1);
        g.goToFrame(
          [...name].reduce((sum, c) => sum + c.codePointAt(0)!, 0) % 140,
        );
      }
    }
    root.rotation.y = role === "civilian" ? Math.PI * 0.85 : Math.PI;
    return {
      root,
      groups,
      role,
      name,
      health: 100,
      base: pos.clone(),
      phase: Math.random() * 6,
      anim: "Idle",
      throwTime: 0,
      hitTime: 0,
      detail,
      action: "Throw",
    };
  }
  private animate(
    a: Actor,
    dt: number,
    moving = false,
    run = false,
    speed = run ? 4.5 : 2.25,
  ) {
    let name =
      a.hitTime > 0
        ? "Hit"
        : a.throwTime > 0
          ? a.action
          : moving
            ? run
              ? "Run"
              : "Walk"
            : "Idle";
    if (a.health <= 0) name = "Idle";
    a.throwTime = Math.max(0, a.throwTime - dt);
    a.hitTime = Math.max(0, a.hitTime - dt);
    for (const group of a.groups) {
      const target = group.name.endsWith(name) ? 1 : 0;
      if (target && name === "Walk")
        group.speedRatio = Math.max(0.1, speed / 1.4);
      if (target && !group.isStarted) {
        group.start(true);
        group.setWeightForAllAnimatables(0);
      }
      const old = group.animatables[0]?.weight ?? 0;
      const weight = old + (target - old) * Math.min(1, dt * 12);
      group.setWeightForAllAnimatables(weight);
      if (!target && weight < 0.01 && group.isStarted) group.stop();
    }
    a.anim = name;
    if (a === this.player) this.playerMotionsSeen.add(name);
  }
  private item(kind: Item, position: Vector3): Mesh {
    if (kind === "egg") {
      const egg = MeshBuilder.CreateSphere(
        "Textured egg",
        { diameterX: 0.136, diameterY: 0.2048, diameterZ: 0.136, segments: 20 },
        this.scene,
      );
      egg.position.copyFrom(position);
      egg.material = material(this.scene, "Egg shell", "#e8ddbc", 0.75);
      return egg;
    }
    const shape = [
      new Vector3(-0.065, 0, -0.14),
      new Vector3(0.062, 0, -0.14),
      new Vector3(0.078, 0, 0.11),
      new Vector3(0.052, 0, 0.19),
      new Vector3(-0.043, 0, 0.2),
      new Vector3(-0.078, 0, 0.1),
    ];
    const positions = [
        0,
        0.01,
        0,
        ...shape.flatMap((p) => [p.x, 0.01, p.z]),
        0,
        -0.02,
        0,
        ...shape.flatMap((p) => [p.x, -0.02, p.z]),
      ],
      indices = [];
    for (let i = 0; i < 6; i++) {
      const n = (i + 1) % 6;
      indices.push(
        0,
        i + 1,
        n + 1,
        7,
        n + 8,
        i + 8,
        i + 1,
        i + 8,
        n + 8,
        i + 1,
        n + 8,
        n + 1,
      );
    }
    const m = new Mesh("Rubber sandal moulded sole", this.scene);
    m.setVerticesData(VertexBuffer.PositionKind, positions);
    m.setIndices(indices);
    m.createNormals(true);
    m.material = material(
      this.scene,
      "Sandal turquoise rubber",
      "#326c65",
      0.84,
    );
    m.position.copyFrom(position);
    const strap = MeshBuilder.CreateTube(
      "Sandal Y strap",
      {
        path: [
          new Vector3(-0.065, 0.025, -0.03),
          new Vector3(0, 0.08, 0.08),
          new Vector3(0.065, 0.025, -0.03),
        ],
        radius: 0.014,
        tessellation: 8,
      },
      this.scene,
    );
    strap.parent = m;
    strap.material = material(this.scene, "Sandal strap", "#a94e30");
    return m;
  }
  private addPickup(kind: Item, p: Vector3) {
    const root = new TransformNode(`${kind} pickup`, this.scene);
    root.position.copyFrom(p);
    for (let i = 0; i < 3; i++) {
      const mesh = this.item(
        kind,
        new Vector3((i - 1) * 0.19, 0, (i % 2) * 0.15),
      );
      mesh.parent = root;
      mesh.scaling.scaleInPlace(1.6);
      this.shadow.addShadowCaster(mesh);
    }
    this.pickups.push({
      root,
      kind,
      origin: p.clone(),
      available: true,
      cooldown: 0,
    });
  }
  private dust() {
    const ps = new ParticleSystem("Sunlit street dust", 40, this.scene);
    ps.particleTexture = texture(this.scene, "Dust mote", 32, 32, (c) => {
      const g = c.createRadialGradient(16, 16, 0, 16, 16, 16);
      g.addColorStop(0, "#ffe5aa");
      g.addColorStop(1, "#ffe5aa00");
      c.fillStyle = g;
      c.fillRect(0, 0, 32, 32);
    });
    ps.emitter = new Vector3(0, 1.2, 0);
    ps.minEmitBox = new Vector3(-5, 0, -15);
    ps.maxEmitBox = new Vector3(5, 4, 23);
    ps.color1 = new Color4(0.8, 0.73, 0.47, 0.08);
    ps.color2 = new Color4(0.7, 0.6, 0.35, 0.04);
    ps.colorDead = new Color4(0.7, 0.6, 0.4, 0);
    ps.minSize = 0.015;
    ps.maxSize = 0.045;
    ps.minLifeTime = 4;
    ps.maxLifeTime = 8;
    ps.emitRate = 4;
    ps.direction1 = new Vector3(0.03, 0.03, 0.06);
    ps.direction2 = new Vector3(0.12, 0.1, 0.15);
    ps.gravity = new Vector3(0, 0, 0);
    ps.start();
  }
  start() {
    if (!this.state.ready) return;
    const { quality, evening, muted } = this.state;
    this.state = {
      ...initial,
      ready: true,
      playing: true,
      quality,
      evening,
      muted,
    };
    this.player.root.position.set(0, 0, -9);
    this.player.root.rotation.set(0, 0, 0);
    this.player.throwTime = 0;
    this.player.hitTime = 0;
    for (const a of this.actors) {
      a.health = 100;
      a.root.position.copyFrom(a.base);
      a.root.rotation.z = 0;
    }
    for (const p of this.pickups) {
      p.available = true;
      p.cooldown = 0;
      p.root.setEnabled(true);
    }
    for (const p of this.projectiles) {
      p.body.dispose();
      p.mesh.getChildMeshes().forEach((m) => m.dispose());
      p.mesh.dispose();
    }
    this.projectiles = [];
    this.resetBenchmark();
    this.playerMotionsSeen.clear();
    this.state.paused = false;
    this.simulationActive = true;
    this.yaw = 0;
    this.pitch = 0.18;
    this.cameraDistance = 4.8;
    this.keys.clear();
    this.touch = { x: 0, y: 0 };
    this.running = false;
    void this.audio
      .start()
      .catch(() =>
        this.message("শব্দ চালু করা যায়নি। সেটিংস থেকে আবার চেষ্টা করুন।"),
      );
    this.audio.setMuted(this.state.muted);
    this.message("সজল, আগে ডিম আর স্যান্ডেল কুড়িয়ে নিন।");
    this.subtitle("চা-মামা: চা খাইয়া যান, প্রতিশ্রুতি ফ্রি!");
    this.emit();
    this.canvas.focus();
  }
  pause() {
    if (!this.state.playing) return;
    if (this.state.paused && this.state.health === 0) {
      this.start();
      return;
    }
    this.state.paused = !this.state.paused;
    this.simulationActive = !this.state.paused;
    this.keys.clear();
    this.touch = { x: 0, y: 0 };
    this.audio.pause(this.state.paused);
    this.emit();
  }
  home() {
    this.state.playing = false;
    this.state.paused = false;
    this.simulationActive = false;
    this.keys.clear();
    this.audio.pause(true);
    this.emit();
  }
  setQuality(q: Quality) {
    this.resetBenchmark();
    this.state.quality = q;
    const s = qualitySettings[q];
    this.engine.setHardwareScalingLevel(s.scale);
    this.shadow.mapSize = s.shadow;
    this.camera.maxZ = s.view;
    this.pipeline.bloomEnabled = q === "desktop";
    if (
      q === "desktop" &&
      this.engine.webGLVersion > 1 &&
      !this.ambientOcclusion
    ) {
      this.ambientOcclusion = new SSAO2RenderingPipeline(
        "Dhaka contact shading",
        this.scene,
        { ssaoRatio: 0.5, blurRatio: 0.5 },
        [this.camera],
      );
      this.ambientOcclusion.radius = 0.55;
      this.ambientOcclusion.totalStrength = 0.65;
      this.ambientOcclusion.samples = 8;
      this.ambientOcclusion.expensiveBlur = false;
      this.ambientOcclusion.maxZ = 45;
      const prepass = this.scene.enablePrePassRenderer();
      if (prepass) prepass.disableGammaTransform = true;
    } else if (q === "mobile" && this.ambientOcclusion) {
      this.ambientOcclusion.dispose();
      this.ambientOcclusion = undefined;
      this.scene.disablePrePassRenderer();
    }
    const dust = this.scene.particleSystems[0];
    if (dust) dust.emitRate = q === "desktop" ? 4 : 1;
    this.emit();
  }
  setEvening(value: boolean) {
    this.resetBenchmark();
    this.state.evening = value;
    this.sun.diffuse = hex(value ? "#ffb776" : "#ffe0ad");
    this.sun.intensity = value ? 2.2 : 2;
    this.sun.direction = value
      ? new Vector3(-0.8, -0.38, 0.5)
      : new Vector3(0.65, -1, 0.5);
    this.sun.position = value
      ? new Vector3(35, 23, -25)
      : new Vector3(-25, 40, -20);
    this.hemi.intensity = value ? 0.42 : 0.32;
    this.scene.fogColor = hex(value ? "#9f8582" : "#b5c3bb");
    this.scene.clearColor = value
      ? new Color4(0.57, 0.42, 0.39, 1)
      : new Color4(0.63, 0.73, 0.74, 1);
    this.scene.environmentIntensity = value ? 0.55 : 0.65;
    this.scene.imageProcessingConfiguration.exposure = value ? 1.2 : 1.03;
    this.emit();
  }
  mute() {
    this.state.muted = !this.state.muted;
    this.audio.setMuted(this.state.muted);
    if (!this.state.muted && this.state.playing) void this.audio.start();
    this.emit();
  }
  select(kind: Item) {
    this.state.selected = kind;
    this.emit();
  }
  joystick(x: number, y: number) {
    this.touch = { x, y };
  }
  run(value: boolean) {
    this.running = value;
  }
  look(dx: number, dy: number) {
    this.yaw += dx * 0.005;
    this.pitch = Math.max(-0.08, Math.min(0.66, this.pitch + dy * 0.003));
  }
  zoom(amount: number) {
    if (!this.simulationActive) return;
    this.cameraDistance = Math.max(1.8, Math.min(6.5, this.cameraDistance + amount));
  }
  resetBenchmark() {
    this.frameWindow.reset();
  }
  pickup() {
    if (!this.simulationActive) return;
    for (const p of this.pickups) {
      if (
        p.available &&
        Vector3.Distance(p.root.position, this.player.root.position) < 2.2
      ) {
        p.available = false;
        p.root.setEnabled(false);
        p.cooldown = 15;
        this.state[p.kind] += 6;
        this.state.selected = p.kind;
        this.player.action = "Pickup";
        this.player.throwTime = 0.85;
        this.player.groups.find((g) => g.name.endsWith("Pickup"))?.reset();
        this.audio.effect();
        this.message(
          `${content.items[p.kind]} কুড়িয়েছেন! সঙ্গে এখন ${bn(this.state[p.kind])}টি।`,
        );
        this.emit();
        return;
      }
    }
    this.message("ডিম বা স্যান্ডেলের একটু কাছে যান।");
  }
  throw() {
    if (
      !this.simulationActive ||
      (this.player.throwTime > 0 && this.player.action === "Throw")
    )
      return;
    const kind = this.state.selected;
    if (this.state[kind] <= 0) {
      this.message(`${content.items[kind]} নেই! আগে কুড়িয়ে নিন।`);
      return;
    }
    this.state[kind]--;
    this.state.throws++;
    this.player.throwTime = 0.8;
    this.player.action = "Throw";
    const throwGroup = this.player.groups.find((g) => g.name.endsWith("Throw"));
    throwGroup?.reset();
    const direction = new Vector3(Math.sin(this.yaw), 0, Math.cos(this.yaw));
    const origin = this.player.root.position.add(
      new Vector3(direction.x * 0.5, 1.3, direction.z * 0.5),
    );
    let target = origin.add(direction.scale(9));
    target.y = 0.8;
    const candidates = this.actors
      .filter((a) => a.health > 0)
      .map((a) => ({
        a,
        delta: a.root.position.subtract(this.player.root.position),
      }))
      .filter(
        ({ delta }) =>
          delta.length() < 14 &&
          Vector3.Dot(delta.normalizeToNew(), direction) > 0.93,
      )
      .sort((a, b) => a.delta.length() - b.delta.length());
    if (candidates[0])
      target = candidates[0].a.root.position.add(new Vector3(0, 1.0, 0));
    const mesh = this.item(kind, origin);
    const body = new PhysicsAggregate(
      mesh,
      PhysicsShapeType.SPHERE,
      {
        mass: 0.18,
        restitution: 0.15,
        friction: 0.6,
        radius: kind === "egg" ? 0.1024 : 0.18,
      },
      this.scene,
    );
    body.body.setLinearVelocity(
      Vector3.FromArray(Object.values(launchVelocity(origin, target))),
    );
    body.body.setAngularVelocity(new Vector3(7, 2, 4));
    this.projectiles.push({ mesh, body, age: 0, kind, hit: false });
    this.shadow.addShadowCaster(mesh);
    this.emit();
  }
  message(text: string) {
    this.state.message = text;
    this.messageUntil = this.time + 5;
  }
  private subtitle(text: string) {
    this.state.subtitle = text;
    this.subtitleUntil = this.time + 4.5;
  }
  private hit(a: Actor, p: Projectile) {
    p.hit = true;
    a.health = Math.max(0, a.health - (p.kind === "egg" ? 25 : 40));
    a.hitTime = 0.45;
    a.groups.find((g) => g.name.endsWith("Hit"))?.reset();
    this.state.hits++;
    const reward = rewardForHit(a.role, p.kind);
    this.state.score += reward;
    this.audio.effect(true);
    if (a.role === "civilian") {
      this.state.civilianHits++;
      this.state.health = Math.max(0, this.state.health - 8);
      this.message(content.civilianWarning);
      this.subtitle(`${a.name}: আরে ভাই, আমি তো চা খাইতে আসছি!`);
    } else {
      this.message(`লেগেছে! +${bn(reward)} পয়েন্ট`);
      this.subtitle(
        a.health <= 0
          ? `${a.name}: আজকের সভা এখানেই শেষ!`
          : `${a.name}: প্রতিশ্রুতি দিলাম, আর রাস্তা আটকাব না!`,
      );
    }
    this.state.target = a.name;
    this.targetUntil = this.time + 4;
    this.state.targetHealth = a.health;
    if (a.health <= 0) {
      a.root.rotation.z = 0.13;
      a.root.position.y = Math.max(0, a.root.position.y - 0.13);
    }
  }
  private frame() {
    if (this.disposed) return;
    const dt = Math.min(this.engine.getDeltaTime() / 1000, 0.05);
    this.time += dt;
    if (this.state.ready) {
      if (!this.state.playing) {
        const t = this.time * 0.025;
        this.camera.position.set(2.2 + Math.sin(t) * 0.5, 3.2, -11.7);
        this.camera.setTarget(new Vector3(-1.7, 1.75, 3.2));
        this.animate(this.player, dt);
      } else if (this.simulationActive) {
        this.updatePlayer(dt);
        this.updateActors(dt);
        this.updatePickups(dt);
        this.updateProjectiles(dt);
        this.updateCamera(dt);
        if (this.time > this.subtitleUntil) this.state.subtitle = "";
        if (this.time > this.targetUntil) this.state.target = "";
        if (this.time > this.messageUntil)
          this.state.message = "রাস্তা খুলুন, পথচারীদের ছাড়ুন।";
      }
      if (!this.simulationActive) {
        for (const a of this.actors) this.animate(a, dt);
      }
      this.scene.physicsEnabled = this.simulationActive;
      this.scene.animationsEnabled = !this.state.paused;
    }
    this.engine._drawCalls.fetchNewFrame();
    this.scene.render();
    if (this.state.ready && this.state.playing && !this.state.paused) {
      this.frameWindow.record(this.engine.getDeltaTime(), document.visibilityState === "visible");
    }
    this.uiTime += dt;
    if (this.uiTime > 0.12) {
      this.uiTime = 0;
      this.state.fps = Math.round(this.engine.getFps());
      if (this.player) {
        this.state.x = this.player.root.position.x;
        this.state.z = this.player.root.position.z;
        this.state.yaw = this.yaw;
      }
      this.emit();
    }
  }
  private updatePlayer(dt: number) {
    const x =
      (this.keys.has("KeyD") || this.keys.has("ArrowRight") ? 1 : 0) -
      (this.keys.has("KeyA") || this.keys.has("ArrowLeft") ? 1 : 0) +
      this.touch.x;
    const z =
      (this.keys.has("KeyW") || this.keys.has("ArrowUp") ? 1 : 0) -
      (this.keys.has("KeyS") || this.keys.has("ArrowDown") ? 1 : 0) -
      this.touch.y;
    const moving = Math.hypot(x, z) > 0.1,
      run =
        this.keys.has("ShiftLeft") ||
        this.keys.has("ShiftRight") ||
        this.running;
    const speed = run ? 4.5 : 2.25;
    const scale = Math.max(1, Math.hypot(x, z)),
      dx =
        ((x * Math.cos(this.yaw) + z * Math.sin(this.yaw)) / scale) *
        speed *
        dt,
      dz =
        ((z * Math.cos(this.yaw) - x * Math.sin(this.yaw)) / scale) *
        speed *
        dt;
    const p = this.player.root.position;
    if (moving) {
      if (canWalk(p.x + dx, p.z, this.world.obstacles)) p.x += dx;
      if (canWalk(p.x, p.z + dz, this.world.obstacles)) p.z += dz;
      const angle = Math.atan2(dx, dz);
      let d = angle - this.player.root.rotation.y;
      d = Math.atan2(Math.sin(d), Math.cos(d));
      this.player.root.rotation.y += d * Math.min(1, dt * 14);
    }
    const edge = Math.abs(p.x);
    p.y = edge > 5.295 && edge < 5.565 ? 0.32 : edge >= 5.565 ? 0.2 : 0;
    this.animate(this.player, dt, moving, run);
    this.state.nearPickup = this.pickups.some(
      (v) => v.available && Vector3.Distance(v.root.position, p) < 2.2,
    );
    const near = this.actors.find(
      (a) =>
        a.role === "worker" &&
        a.health > 0 &&
        Vector3.Distance(a.root.position, p) < 1.05,
    );
    if (near && this.time - this.healthTime > 2.3) {
      this.healthTime = this.time;
      this.state.health = Math.max(0, this.state.health - 5);
      this.message("ভিড়ের ধাক্কা! একটু দূরে থাকুন।");
    }
    if (this.state.health === 0) {
      this.message("একটু চা-বিরতি! নতুন করে চেষ্টা করুন।");
      this.state.paused = true;
      this.simulationActive = false;
    }
  }
  private updateActors(dt: number) {
    for (const a of this.actors) {
      const detailed =
        Vector3.DistanceSquared(a.root.position, this.camera.position) < 144;
      for (const mesh of a.detail) mesh.isVisible = detailed;
      let moving = false,
        speed = 0;
      if (a.health > 0) {
        if (a.role === "civilian" && a.name !== content.civilians[4]) {
          const phase = this.time * 0.32 + a.phase;
          a.root.position.z = a.base.z + Math.sin(phase) * 1.5;
          speed = Math.abs(Math.cos(phase) * 0.48);
          moving = speed > 0.12;
          const desired = Math.cos(phase) > 0 ? 0 : Math.PI,
            delta = Math.atan2(
              Math.sin(desired - a.root.rotation.y),
              Math.cos(desired - a.root.rotation.y),
            );
          a.root.rotation.y += delta * Math.min(1, dt * 3.5);
        } else {
          const baseAngle = a.role === "civilian" ? Math.PI * 0.85 : Math.PI;
          a.root.rotation.y =
            baseAngle + Math.sin(this.time * 0.3 + a.phase) * 0.07;
        }
      }
      this.animate(a, dt, moving, false, speed);
    }
  }
  private updatePickups(dt: number) {
    for (const p of this.pickups) {
      if (!p.available) {
        p.cooldown -= dt;
        if (p.cooldown <= 0) {
          p.available = true;
          p.root.setEnabled(true);
        }
        continue;
      }
      p.root.position.y = p.origin.y + 0.05 + Math.sin(this.time * 2) * 0.04;
      p.root.rotation.y = Math.sin(this.time * 0.6) * 0.15;
    }
  }
  private updateProjectiles(dt: number) {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.age += dt;
      if (!p.hit)
        for (const a of this.actors) {
          if (a.health <= 0) continue;
          const center = a.root.position.add(new Vector3(0, 1, 0));
          if (Vector3.Distance(p.mesh.position, center) < 0.58) {
            this.hit(a, p);
            break;
          }
        }
      if (p.age > 4 || p.hit) {
        p.body.dispose();
        p.mesh.getChildMeshes().forEach((m) => m.dispose());
        p.mesh.dispose();
        this.projectiles.splice(i, 1);
      }
    }
  }
  private updateCamera(dt: number) {
    this.audio.listener(
      this.player.root.position.x,
      this.player.root.position.z,
      this.yaw,
    );
    const target = this.player.root.position.add(new Vector3(0, 1.28, 0));
    const back = new Vector3(
      -Math.sin(this.yaw) * this.cameraDistance,
      0.35 + this.pitch * this.cameraDistance,
      -Math.cos(this.yaw) * this.cameraDistance,
    );
    const ideal = target.add(back);
    const dir = ideal.subtract(target);
    const ray = new Ray(target, dir.normalizeToNew(), dir.length());
    let dist = dir.length();
    for (const m of this.colliders) {
      const hit = ray.intersectsMesh(m, false);
      if (hit.hit && hit.distance > 0.1)
        dist = Math.min(dist, Math.max(0.65, hit.distance - 0.35));
    }
    const desired = target.add(dir.normalizeToNew().scale(dist));
    this.camera.position =
      Vector3.Distance(this.camera.position, target) > dist
        ? desired
        : Vector3.Lerp(this.camera.position, desired, Math.min(1, dt * 10));
    this.camera.setTarget(
      target.add(
        new Vector3(Math.sin(this.yaw) * 0.6, 0.05, Math.cos(this.yaw) * 0.6),
      ),
    );
  }
  private listen() {
    const on = <K extends keyof WindowEventMap>(
      key: K,
      fn: (e: WindowEventMap[K]) => void,
    ) => {
      window.addEventListener(key, fn);
      this.cleanup.push(() => window.removeEventListener(key, fn));
    };
    on("keydown", (e) => {
      if ((e.target as HTMLElement).matches("input,select,textarea")) return;
      if (e.code === "Escape") {
        if (!e.repeat) this.pause();
        return;
      }
      if (!this.simulationActive) return;
      if (
        ["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(
          e.code,
        )
      )
        e.preventDefault();
      this.keys.add(e.code);
      if (e.repeat) return;
      if (e.code === "KeyE") this.pickup();
      if (e.code === "Space") this.throw();
      if (e.code === "Digit1") this.select("egg");
      if (e.code === "Digit2") this.select("sandal");
    });
    on("keyup", (e) => this.keys.delete(e.code));
    on("blur", () => {
      this.keys.clear();
      this.touch = { x: 0, y: 0 };
    });
    on("resize", () => this.engine.resize());
    const down = (e: PointerEvent) => {
      if (!this.simulationActive || e.button !== 0) return;
      this.pointer = { id: e.pointerId, x: e.clientX, y: e.clientY };
      this.canvas.setPointerCapture(e.pointerId);
    };
    const move = (e: PointerEvent) => {
      if (!this.pointer || this.pointer.id !== e.pointerId) return;
      this.look(e.clientX - this.pointer.x, e.clientY - this.pointer.y);
      this.pointer.x = e.clientX;
      this.pointer.y = e.clientY;
    };
    const up = () => {
      this.pointer = undefined;
    };
    const zoom = (event: WheelEvent) => {
      if (!this.simulationActive) return;
      event.preventDefault();
      this.zoom(event.deltaY * 0.0036);
    };
    this.canvas.addEventListener("wheel", zoom, { passive: false });
    this.canvas.addEventListener("pointerdown", down);
    this.canvas.addEventListener("pointermove", move);
    this.canvas.addEventListener("pointerup", up);
    this.canvas.addEventListener("pointercancel", up);
    this.cleanup.push(() => {
      this.canvas.removeEventListener("pointerdown", down);
      this.canvas.removeEventListener("pointermove", move);
      this.canvas.removeEventListener("pointerup", up);
      this.canvas.removeEventListener("pointercancel", up);
      this.canvas.removeEventListener("wheel", zoom);
    });
  }
  private emit() {
    this.onChange({ ...this.state });
  }
  diagnostics() {
    return {
      ...this.frameWindow.summary(),
      pageVisible: document.visibilityState === "visible",
      playerMotionsSeen: [...this.playerMotionsSeen],
      cameraPerspective: this.camera.mode === 0,
      cameraDistance: this.cameraDistance,
      hdrReady: this.scene.environmentTexture?.isReady() ?? false,
      ambientOcclusion: !!this.ambientOcclusion,
      actorStates: [this.player, ...this.actors]
        .filter((a) => !!a)
        .map((a) => ({
          name: a.name,
          role: a.role,
          animation: a.anim,
          localGarments: a.root
            .getChildMeshes()
            .filter(
              (m) =>
                /optional tunic|Optional woven|Optional long|Optional moustache/.test(
                  m.name,
                ) && m.isEnabled(),
            )
            .map((m) => m.name),
        })),
      meshes: this.scene.meshes.length,
      activeMeshes: this.scene.getActiveMeshes().length,
      drawCalls: this.engine._drawCalls.current,
      position: this.player?.root.position.asArray(),
      cameraPosition: this.camera.position.asArray(),
      skeletons: this.scene.skeletons.length,
      animationGroups: this.scene.animationGroups.length,
      physics: !!this.scene.getPhysicsEngine(),
      audio: this.audio.status,
      ...this.state,
    };
  }
  dispose() {
    this.disposed = true;
    this.cleanup.forEach((f) => f());
    this.audio.dispose();
    this.projectiles.forEach((p) => p.body.dispose());
    this.scene.dispose();
    this.engine.dispose();
  }
}
