# Actual build evidence

## Phase 00 — 2026-11-02

Read-only audit completed before edits. Working directory empty; `git status` and `git rev-parse` both report not a Git repository. No unrelated application or user work found. Node 26.5.0 and npm 11.17.0 available; Blender not found on PATH. No database touched.

Harness created: AGENTS, GOALS, PLANS, seven gated phase specifications, context decisions, this log.

Current API references via Context7:
- Babylon official documentation: `await HavokPhysics()` then `new HavokPlugin(true, instance)` and `scene.enablePhysics`; Physics V2 aggregates; collision flags.
- Vite official documentation: Vite 8 supports Node >=22.12.0 (local Node satisfies).
- Colyseus official migration documentation: `colyseus`, `@colyseus/sdk`, `@colyseus/schema` current package families. Deferred without installation.

## Phase 01

Implementation and observed verification are appended below as work proceeds. No visual approval or device-performance claim is implied by this scaffold.

### Implemented

Standalone npm/TypeScript workspaces; Vite/React Bengali interface; Babylon 9.33.1; Havok 1.3.14 Physics V2. Reserved Admin/server folders contain boundary documentation only. Original reproducible skinned GLB (17 joints, five clips), ten runtime actors, detailed procedural architecture/props/vehicles and original local textures. Bundled Noto Sans Bengali and copied license notices. Spatial Web Audio uses synthesised motors/horns without voices. No database or external service is used.

Current npm metadata checked: Babylon 9.33.1, Havok 1.3.14, Vite 8.3.5, Colyseus 0.18.10, SDK 0.18.9, schema 5.0.43. Only packages needed for the slice installed. Context7's Colyseus migration examples used for package-family confirmation; multiplayer is deferred.

### Verification and fixes observed

- `npm run verify`: type checking, ESLint, 5 meaningful tests and production build passed after the last gameplay source change. Actual output saved in `harness/evidence/checks.txt`.
- Production preview served at http://127.0.0.1:4173/ and inspected using actual browser rendering.
- Desktop tested at 1280×720; mobile viewport at 390×844. Keyboard W moved forward; Shift+W covered about twice the distance. E collected eggs and sandals. Space/mobile throw button produced +8 for sandal and +5 for egg, with target health reductions and Bengali subtitles.
- Actual mobile joystick pointer hold changed z from -9 to about -7.33; touch collect and throw completed successfully (`mobile-joystick.json` and screenshots).
- Counter collision held x=-5.750775 before/after an additional 1-second A input (`collision.json`). That early file's draw-call field was cumulative, not a per-frame count; do not use it for performance comparisons. Per-frame counter was corrected later.
- Roof initially obscured the player. Added correct-height camera proxies for roof, awning and sign; close view observed with camera y≈2.46 instead of y≈3.91 (`camera-roof-fixed.*`). Camera now retracts immediately when obstructed. Corrected foot height at curbs/pavement.
- Side-facing Bengali signs initially showed their reverse side. Corrected plane orientation and visually read “কেটলি কেবিনেট” from the road. Bengali shaping sample checked on desktop/mobile. Danda U+0964 is shared Bengali punctuation, not evidence of Hindi text; no Devanagari letters were found. No Unicode replacement character was found. Mobile DOM scroll width matched viewport width (390).
- Pause retry passed with paused=true, suspended audio and identical before/after position (`pause-retry.json`). Preserve `pause.json` as an invalid initial test setup: it recorded paused=false, so its failed frozen result is not a pause-engine failure or a pass.
- Improved frame cost by stopping zero-weight animation groups, reducing distant tiny details and avoiding their shadow passes. Final captured 600-sample averages: desktop street 59.36, desktop evening 59.95, mobile viewport 59.98 FPS. These are local computer results, not Android hardware claims.
- Babylon warned while automatically inferring a sphere from the oval egg's bounds. Preserved the oval render geometry and assigned explicit, simple spherical collision radii (egg 0.1024 m, sandal 0.18 m); render and collider shape are deliberately separate. Last build and egg throw rechecked after this correction.
- Browser connection recovery was needed during verification; reconnecting the existing tab after a session reset worked. No app data was lost.
- Final explicit-collider egg smoke check produced +5 points, target health 75 and an empty new-run warning/error list (`final-egg-check.json`). Build/check output was refreshed after the final source change. Settings screenshots were inspected and recaptured after layout settled. Returned the browser to the ordinary, Bengali game URL and cleared the temporary viewport override.

### Art and gate

Three gameplay-angle screenshots plus home, settings, mobile and shaping proof are in `harness/evidence`. See `harness/phase-01-status.md` for the complete acceptance matrix and asset limitations. The functional slice is reviewable. The current character/vehicle artwork is stylized and is **not asserted to meet the final semi-realistic visual target**. No Phase 02–06 work has been started and no phase approval is inferred.

## Photo-led graphics revision — 2026-11-02

Scope stayed within Phase 01. Read-only audit preceded changes; prior files/model preserved in `assets/source/archive/phase01-before-photo-upgrade.zip`. Eleven supplied photographs were archived with dimensions, SHA-256 and reference roles. Real portraits/logos were not published. Geometry is authored, not photo reconstruction.

Rebuilt rickshaw/CNG/bus geometry in `vehicles.ts`; added asphalt/plaster/enamel/floral local material sets, HDR lighting/reflections, desktop SSAO, corrected puddle normals, foliage trees, drains, yellow pedestrian railings and original Bengali posters. Built-in imagegen produced the saved material atlas; exact prompt/mode are retained. Normal/ORM estimates were reduced to 512 square, bringing all twelve maps to about 3.1 MB. Added Sharp only as offline dev tooling. CC0 HDR from Poly Haven and its provenance are local.

Original skinned GLB now has six clips including Pickup, refined face/limbs/clothing and optional local garments. Ten actors share 17-joint anatomy, with garment/hair/skin/scale variants and ambient sidewalk Walk. Camera moved lower; orbit retained and wheel zoom implemented. Vehicle/median/tree colliders updated. Full detail and limitations: `harness/graphics-upgrade.md`.

### Actual fixes and verification

- New polygon vehicle panels initially failed static merging due to missing UV data. Added UVs and correct single-face normals/two-sided material; startup was retested successfully. Lower body lofts were adjusted to avoid enclosing seats. Sky blur causing an oversized sun glow was removed.
- Final gameplay-source `npm run verify` passed types, lint, six tests and production build. Output: `harness/evidence/graphics-v2-checks.txt`. Skin-weight normalization, six clips, PBR maps/HDR budgets and existing gameplay rules are checked. Vite retains a 2.67 MB 3D chunk advisory; no failed build.
- Production preview on port 4173 rendered in Chrome. IAB background throttled to roughly 1 FPS, so those results were excluded from performance claims. Saved 600-sample means: desktop street 60.00, desktop bus angle 53.31, mobile viewport 56.32 FPS. Other interactions showed 25–30 FPS. These are brief local-PC observations, not stable-frame-rate or real-phone qualification.
- At 390x844, mobile preset had HDR ready/AO off and no horizontal DOM overflow. Joystick moved from z=-9 to -7.61 and then to the egg pickup. Touch collect gave six eggs; throw consumed one, scored +5 and reduced target to 75 health. `graphics-v2/mobile-*.json`.
- Shift+W traversed to the bus. New divider blocked x at -0.8832547257 before/after additional D input while permitting sliding along z. Escape pause held the same position during W input and suspended audio. `graphics-v2/divider-collision.json`, `pause.json`.
- Bengali shaping sample was visually inspected on desktop/mobile; bn-BD, bundled Noto Sans Bengali, no replacement character or Devanagari letters. New test-tab warning/error list was empty. Temporary viewports reset; separate QA tab closed; existing played game tab retained without resetting progress.
- Actual screenshots include street/CNG, character/rickshaw, opposite rickshaw view, bus/divider and mobile settings/game/Bengali proof. Wheel zoom's controlled native-input check remains incomplete because native window activation failed; implementation alone is not recorded as a passed input test.

Art remains stylized; final semi-realistic art acceptance and real-device performance remain open. No Phase 02–06 features were started.

## Phase 00–01 resumption and interrupted final QA — 2026-11-02

Read-only audit confirmed `D:/neta-udche -3d` is the existing standalone `neta-uthche` game, not clothing commerce. Git reports no repository. Preserved existing instructions/goals/specs/source/data. Context7 rechecked official Babylon/Havok/Vite APIs; normal-network npm metadata matched installed Babylon 9.33.1, Havok 1.3.14 and Vite 8.3.5. Initial restricted-network failure was resolved with read-only normal-network access. Production preview on 4173 returned HTTP 200 and the game HTML.

Added elapsed-frame-time FPS statistics/reset/test, Bengali camera distance buttons, motion diagnostics and text-selection prevention. Corrected merged static shadow casting to preserve original caster intent and froze static world matrices. Close art inspection found white box biscuit props; replaced their source with transparent lathed jars, biscuit stacks/tin lids, stove details and framed distant windows. Latest final-source verify passed types, lint, seven tests and production build (`harness/evidence/phase01-recheck-checks.txt`). No new runtime dependency or later-phase implementation.

Before that final prop-only edit, actual desktop gameplay with the same camera/movement/physics code showed Walk/Run/Pickup/Throw, +5 egg and +8 sandal rewards, counter collision at x=-5.699025 and awning camera retraction to about 1.5446 m target distance from a nominal 4.8 m. Three angle images and JSONs are in `harness/evidence/phase01-review`. The initial out-of-range pickup attempt failed as expected; it is not a passed collection. Time-weighted desktop samples measured 23.59 and 23.26 FPS over 600 frames, with background/occlusion throttling also observed; do not reuse prior higher FPS as a current stable-performance pass.

Latest prop build reached Bengali HUD in Chrome/IAB, but final prop appearance and fresh mobile/preset/shaping/three-angle regression were interrupted. IAB preview was opened in the Codex panel after background throttling; the user agreed to keep it in front. Browser calls then timed out. After explicit session reset, inventory reported: user stopped Computer Use with physical Escape; do not make further Computer Use calls. UI work stopped at that point. Temporary 1280x720 overrides could not be reset/verified after the interruption. Existing played game state was not reset/deleted.

See `harness/phase-01-review.md` for accurate current acceptance status, file list, provenance and remaining work. **Phase 01 is not complete or visually approved.** Final mobile/visual/performance gates remain open. No Phase 02–06 work started.
