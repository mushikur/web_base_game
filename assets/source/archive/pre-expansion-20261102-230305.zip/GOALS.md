# নেতা উঠছে!

স্লোগান: **প্রতিশ্রুতি অনেক। রাস্তাটা ছাড়েন!**

Build one standalone third-person browser game with an unmistakably fictional Dhaka street and Bengali-first interface. Current deliverable is one playable block around **কেটলি কেবিনেট**, not a complete city or finished release.

## Current success criteria

One detailed street, original rigged GLB player, walking/running and camera collision; one leader, three workers, five civilians; rickshaw and green CNG; egg/sandal pickups and animated throws with physical projectile arcs; collision, health, score, minimap, daylight/evening, traffic audio, quality presets, Bengali desktop/mobile UI.

## Cultural direction

Use rickshaw floral painting, concrete balconies, tin-roof tea shops, black/yellow curbs, road dividers, tangled utility wires, weathered asphalt, local clothing and Bengali humour. All characters and affiliations are fictional. No blood or real electrocution.

## Language contract

UTF-8, `lang=bn-BD`, bundled shaping-capable Bengali font, complete phrases rather than codepoint slicing. Verify যুক্তাক্ষর, কার, ফলা, punctuation, wrapping and mobile clipping. Bengali numbers use `Intl.NumberFormat('bn-BD')`. No English placeholder surfaces in the game.

## Deferred

Full combat/AI/news (02), driving/full city/weather (03), content Admin/storage (04), multiplayer/referrals (05), release/device qualification (06).
