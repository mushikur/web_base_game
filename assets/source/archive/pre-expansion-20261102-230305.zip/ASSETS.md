# Asset and software provenance

## Original project artwork

- `public/assets/models/dhaka-character.glb`: original 17-joint skinned character with six clips (Idle, Walk, Run, Throw, Hit, Pickup). Revision 2 refines face/limb anatomy, weighted cotton folds/collar, optional panjabi/kameez/dupatta, hair and moustache, plus pelvis stance compensation. Editable source: `assets/source/generate.mjs`; regenerate with `npm run assets`. No scanned person or copied identity.
- Environment and vehicle geometry is authored in `world.ts`, `vehicles.ts`, `sceneDetails.ts`, `characterStyle.ts`, `art.ts` and `game.ts`.
- Built-in imagegen produced `assets/source/generated/dhaka-surface-atlas-v2.png` using the supplied street/rickshaw/CNG pictures as visual references. Exact prompt and roles: `assets/source/generated/prompts.md`. Runtime materials in `public/assets/textures` contain 1024² albedo and 512² approximate normal/ORM maps; regenerate conversions with `npm run assets:materials`. These are estimated/generated materials, not measured photogrammetry.
- All runtime textures, HDR lighting, fonts and models are bundled locally; no remote/CDN runtime dependency. Dust, foliage, cotton weave, Bengali signs and fictional posters are original procedural artwork.
- Traffic bed, motor hum, stereo horns and feedback tones: original Web Audio synthesis in `audio.ts`. No recordings or voice clones.
- UI vector icons and map: original SVG in `main.tsx`.

Original project artwork is supplied as part of this project for the user's use and editing. Source is procedural, not a Blender `.blend` file; Blender was unavailable locally. Characters share a base skeleton/anatomy with garment, hair, skin-tone and scale variations. This is not photo-to-character technology or cloth simulation.

The user's eleven original photographs remain unchanged at `D:/game image`; source copies, dimensions, hashes and roles are archived under `assets/source/references`. Their ownership/licenses were not independently established. No complete supplied photograph, real political portrait, real organisation logo or real-person face texture is published in the game.

## Third-party assets

| Item | Version/source | License |
| --- | --- | --- |
| Noto Sans Bengali, bundled regular/semibold/bold/extrabold WOFF2 | `@fontsource/noto-sans-bengali`; Noto Project Authors | SIL Open Font License 1.1; copied to `public/assets/licenses/Noto-Sans-Bengali-OFL.txt` |
| Babylon.js core and glTF loader | 9.33.1 npm packages | Apache-2.0; notices copied under `public/assets/licenses/` |
| Babylon Havok WebAssembly package | 1.3.14 npm package | Package MIT license copied under `public/assets/licenses/` |
| React / React DOM | package lock | MIT; package notices retained in dependencies |
| Kloofendal 48d Partly Cloudy (Pure Sky), 1k HDR | Greg Zaal / Jarod Guest; [Poly Haven](https://polyhaven.com/a/kloofendal_48d_partly_cloudy_puresky) | [CC0](https://polyhaven.com/license); local `public/assets/environment/dhaka-daylight-sky-1k.hdr`; exact metadata in `assets/source/generated/environment-provenance.json` |

Vite, TypeScript, ESLint, typescript-eslint, Prettier and Sharp are development tools, not game artwork. Sharp is used only for offline asset conversion/tests, never imported into the browser. Exact resolved versions/integrity hashes are in `package-lock.json`. Colyseus, MongoDB, Mongoose, Redis and Admin dependencies were not installed; those phases remain gated.
